export type AppointmentStatus = 'pending' | 'confirmed' | 'cancelled' | 'completed';

export interface MedicalService {
  id: string;
  name: string;
  category: string;
  shortDescription: string;
  fullDescription: string;
  iconName: string;
  durationMinutes: number;
  consultationFee: string;
  availableDays: string[];
  isActive: boolean;
  features: string[];
}

export interface Doctor {
  id: string;
  name: string;
  title: string;
  role: string;
  department: string;
  specializations: string[];
  qualifications: string;
  experienceYears: number;
  bio: string;
  photoUrl: string;
  availableDays: string[];
  isAvailable: boolean;
  phone?: string;
  email?: string;
}

export interface Appointment {
  id: string;
  referenceCode: string;
  patientName: string;
  patientPhone: string;
  patientEmail: string;
  serviceId: string;
  serviceName: string;
  doctorId?: string;
  doctorName?: string;
  appointmentDate: string;
  timeSlot: string;
  notes?: string;
  status: AppointmentStatus;
  createdAt: string;
  updatedAt?: string;
}

export interface SiteContent {
  hospitalName: string;
  tagline: string;
  welcomeTitle: string;
  welcomeMessage: string;
  welcomeSubtext: string;
  phone: string;
  whatsappNumber: string;
  emergencyNotice: string;
  address: string;
  workingHours: string;
  email: string;
  announcementText?: string;
}

export interface AdminUser {
  id: string;
  username: string;
  email: string;
  role: string;
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  isConnected: boolean;
  lastTestedAt?: string;
}
