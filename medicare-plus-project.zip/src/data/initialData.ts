import { Doctor, MedicalService, SiteContent, Appointment } from '../types';

export const HERO_IMAGE = '/assets/images/hero_medicare_hospital_1793519704990.jpg';
export const DIAGNOSTICS_IMAGE = '/assets/images/hospital_diagnostics_lab_1793519706973.jpg';

export const INITIAL_SERVICES: MedicalService[] = [
  {
    id: 'srv-1',
    name: 'General Consultation',
    category: 'Primary Care',
    shortDescription: 'Comprehensive medical assessment, preventive health screenings, and tailored therapy plans.',
    fullDescription: 'Our primary care physicians conduct comprehensive clinical check-ups, review medical histories, treat acute illnesses, and help manage long-term wellness.',
    iconName: 'Stethoscope',
    durationMinutes: 30,
    consultationFee: '₦15,000 / $25',
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    isActive: true,
    features: ['Thorough physical examination', 'Prescription & medication review', 'Preventative health roadmap', 'Referral coordination']
  },
  {
    id: 'srv-2',
    name: 'Dental Care',
    category: 'Specialist Care',
    shortDescription: 'Advanced oral hygiene, restorative dentistry, painless extractions, and cosmetic orthodontics.',
    fullDescription: 'State-of-the-art dental clinic providing preventative cleanings, root canal therapy, digital dental X-rays, cavity fillings, and restorative smile enhancements.',
    iconName: 'Smile',
    durationMinutes: 45,
    consultationFee: '₦20,000 / $35',
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    isActive: true,
    features: ['Ultrasonic tartar removal', 'Digital intraoral imaging', 'Painless tooth restorations', 'Gum health assessment']
  },
  {
    id: 'srv-3',
    name: 'Maternity Care',
    category: 'Women Health',
    shortDescription: 'Dedicated prenatal monitoring, safe delivery suites, and postnatal mother-baby support.',
    fullDescription: 'Compassionate maternal care for expectant mothers throughout pregnancy stages, including 4D ultrasound scans, genetic screening, delivery care, and lactation support.',
    iconName: 'HeartPulse',
    durationMinutes: 45,
    consultationFee: '₦25,000 / $40',
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    isActive: true,
    features: ['Routine obstetric ultrasonography', 'Maternal nutritional guidance', 'Postpartum healing reviews', 'Neonatal nursery care']
  },
  {
    id: 'srv-4',
    name: 'Paediatrics',
    category: 'Child Health',
    shortDescription: 'Specialised medical care for newborns, infants, children, and growing adolescents.',
    fullDescription: 'Child-friendly clinical environments designed to support immunization schedules, growth milestone evaluations, common childhood infection management, and pediatric wellness.',
    iconName: 'Baby',
    durationMinutes: 30,
    consultationFee: '₦18,000 / $30',
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    isActive: true,
    features: ['WHO immunization schedules', 'Developmental tracking', 'Pediatric allergy testing', 'Gentle examination techniques']
  },
  {
    id: 'srv-5',
    name: 'Laboratory and Diagnostics',
    category: 'Diagnostics',
    shortDescription: 'Fully automated pathology, microbiology, clinical biochemistry, and rapid result reporting.',
    fullDescription: 'Certified clinical diagnostic laboratory equipped with automated blood analyzers, digital microbiology, lipid profiles, hormonal assays, and same-day electronic result dispatch.',
    iconName: 'FlaskConical',
    durationMinutes: 20,
    consultationFee: 'Varies by test',
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    isActive: true,
    features: ['Complete blood count (CBC)', 'Organ function panels', 'Digital result portal', 'Sterile sample phlebotomy']
  },
  {
    id: 'srv-6',
    name: 'Family Healthcare',
    category: 'Primary Care',
    shortDescription: 'Holistic health plans protecting every generation of your household under unified records.',
    fullDescription: 'Continuous, coordinated healthcare for multi-generational families. We manage hypertension, diabetes, seasonal illnesses, and routine annual wellness physicals for all ages.',
    iconName: 'Users',
    durationMinutes: 45,
    consultationFee: '₦30,000 / $50',
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    isActive: true,
    features: ['Multi-member record management', 'Chronic disease monitoring', 'Senior citizen care packages', 'Home health coordination']
  },
  {
    id: 'srv-7',
    name: 'Specialist Consultations',
    category: 'Specialist Care',
    shortDescription: 'Direct access to senior consultant cardiologists, neurologists, surgeons, and endocrinologists.',
    fullDescription: 'Collaborative care with certified medical specialists for complex diagnostics, second opinions, pre-operative evaluations, and specialized treatment strategies.',
    iconName: 'GraduationCap',
    durationMinutes: 60,
    consultationFee: '₦35,000 / $60',
    availableDays: ['Tuesday', 'Thursday', 'Saturday'],
    isActive: true,
    features: ['Sub-specialty diagnostic reviews', 'Comprehensive treatment roadmaps', 'Multidisciplinary case boards', 'Direct physician follow-up']
  }
];

export const INITIAL_DOCTORS: Doctor[] = [
  {
    id: 'doc-1',
    name: 'Dr. Adebayo Okonkwo',
    title: 'Chief Medical Director & Consultant Physician',
    role: 'CMD / Internal Medicine',
    department: 'Internal Medicine & Cardiology',
    specializations: ['Internal Medicine', 'Cardiovascular Health', 'Preventative Medicine'],
    qualifications: 'MBBS, FWACP, MSc Clin. Epi (Oxon)',
    experienceYears: 18,
    bio: 'Fellow of the West African College of Physicians with extensive clinical leadership in cardiovascular risk mitigation and holistic adult medicine.',
    photoUrl: '/assets/images/doctor_adebayo_cmd_1793519705589.jpg',
    availableDays: ['Monday', 'Wednesday', 'Friday'],
    isAvailable: true,
    phone: '+234 902 497 1419',
    email: 'a.okonkwo@medicareplus.com'
  },
  {
    id: 'doc-2',
    name: 'Dr. Sarah Jenkins',
    title: 'Consultant Obstetrician & Gynaecologist',
    role: 'Lead Obstetrician',
    department: 'Maternity & Women’s Health',
    specializations: ['High-Risk Obstetrics', 'Maternal-Fetal Medicine', 'Minimally Invasive Surgery'],
    qualifications: 'MD, MRCOG (UK), FWACS',
    experienceYears: 14,
    bio: 'Dedicated to empathetic, evidence-based maternal health and guiding mothers through safe, joyful pregnancy and birth experiences.',
    photoUrl: '/assets/images/doctor_sarah_obgyn_1793519706364.jpg',
    availableDays: ['Tuesday', 'Thursday', 'Saturday'],
    isAvailable: true,
    phone: '+234 902 497 1419',
    email: 's.jenkins@medicareplus.com'
  },
  {
    id: 'doc-3',
    name: 'Dr. Chioma Nwosu',
    title: 'Specialist Paediatrician',
    role: 'Head of Paediatrics',
    department: 'Paediatrics & Child Health',
    specializations: ['Neonatology', 'Childhood Infectious Diseases', 'Developmental Paediatrics'],
    qualifications: 'MBBS, FWACP (Paed), MPH',
    experienceYears: 11,
    bio: 'Renowned for gentle, child-focused clinical care, comprehensive vaccine programs, and supporting parent peace of mind at every step.',
    photoUrl: '/assets/images/doctor_chioma_paediatrics_1793519707215.jpg',
    availableDays: ['Monday', 'Tuesday', 'Thursday', 'Friday'],
    isAvailable: true,
    phone: '+234 902 497 1419',
    email: 'c.nwosu@medicareplus.com'
  },
  {
    id: 'doc-4',
    name: 'Dr. Emeka Eze',
    title: 'Consultant Dental Surgeon',
    role: 'Head of Dental Surgery',
    department: 'Dental Surgery & Oral Medicine',
    specializations: ['Endodontics', 'Aesthetic Restorations', 'Oral Surgery'],
    qualifications: 'BDS, FWACS (Oral Surg)',
    experienceYears: 12,
    bio: 'Specialist in minimally invasive dental surgery, restorative dentistry, and making dental visits painless and reassuring.',
    photoUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80',
    availableDays: ['Monday', 'Wednesday', 'Thursday', 'Friday'],
    isAvailable: true,
    phone: '+234 902 497 1419',
    email: 'e.eze@medicareplus.com'
  }
];

export const INITIAL_SITE_CONTENT: SiteContent = {
  hospitalName: 'MEDICARE PLUS',
  tagline: 'Modern Healthcare & Hospital Platform',
  welcomeTitle: 'Welcome to MEDICARE PLUS Clinical Excellence',
  welcomeMessage: 'Dedicated to delivering compassionate, evidence-based medical care for families and individuals. With certified medical specialists, cutting-edge diagnostic laboratories, and personalized patient care pathways, Medicare Plus stands as your trusted healthcare sanctuary.',
  welcomeSubtext: 'Certified Healthcare Professionals · Fast Track Appointments · Modern Diagnostics Suite',
  phone: '09024971419',
  whatsappNumber: '09024971419',
  emergencyNotice: 'Medicare Plus provides scheduled clinical care, diagnostic assessments, and planned consultations. For acute life-threatening emergencies, please proceed immediately to the nearest tertiary emergency department or dial emergency services (112).',
  address: 'Plot 14, Health Park Boulevard, Victoria Island, Lagos, Nigeria',
  workingHours: 'Mon - Fri: 8:00 AM - 7:00 PM | Sat: 9:00 AM - 4:00 PM',
  email: 'care@medicareplus.com',
  announcementText: 'Now open for online appointment bookings and direct WhatsApp clinical support.'
};

export const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-101',
    referenceCode: 'MCP-84920',
    patientName: 'Kelechi Amadi',
    patientPhone: '08031234567',
    patientEmail: 'kelechi.amadi@gmail.com',
    serviceId: 'srv-1',
    serviceName: 'General Consultation',
    doctorId: 'doc-1',
    doctorName: 'Dr. Adebayo Okonkwo',
    appointmentDate: '2026-11-04',
    timeSlot: '10:00 AM - 10:30 AM',
    notes: 'Routine blood pressure review and annual physical examination.',
    status: 'confirmed',
    createdAt: '2026-10-30T14:20:00Z'
  },
  {
    id: 'apt-102',
    referenceCode: 'MCP-84921',
    patientName: 'Amina Bello',
    patientPhone: '09029876543',
    patientEmail: 'amina.bello@yahoo.com',
    serviceId: 'srv-3',
    serviceName: 'Maternity Care',
    doctorId: 'doc-2',
    doctorName: 'Dr. Sarah Jenkins',
    appointmentDate: '2026-11-05',
    timeSlot: '02:00 PM - 02:45 PM',
    notes: 'Second trimester ultrasound scan and nutritional checkup.',
    status: 'pending',
    createdAt: '2026-10-31T09:15:00Z'
  },
  {
    id: 'apt-103',
    referenceCode: 'MCP-84922',
    patientName: 'David Adeleke',
    patientPhone: '08123456789',
    patientEmail: 'd.adeleke@outlook.com',
    serviceId: 'srv-2',
    serviceName: 'Dental Care',
    doctorId: 'doc-4',
    doctorName: 'Dr. Emeka Eze',
    appointmentDate: '2026-11-06',
    timeSlot: '11:30 AM - 12:15 PM',
    notes: 'Dental cleaning and mild molar sensitivity evaluation.',
    status: 'pending',
    createdAt: '2026-10-31T16:40:00Z'
  },
  {
    id: 'apt-104',
    referenceCode: 'MCP-84918',
    patientName: 'Fatima Aliyu',
    patientPhone: '08087654321',
    patientEmail: 'fatima.aliyu@gmail.com',
    serviceId: 'srv-4',
    serviceName: 'Paediatrics',
    doctorId: 'doc-3',
    doctorName: 'Dr. Chioma Nwosu',
    appointmentDate: '2026-10-29',
    timeSlot: '09:00 AM - 09:30 AM',
    notes: '12-month childhood immunization review and growth check.',
    status: 'completed',
    createdAt: '2026-10-25T11:00:00Z'
  }
];

export const TESTIMONIALS = [
  {
    id: 't-1',
    name: 'Engr. Tunde Bakare',
    role: 'Patient, General Medicine',
    outcome: 'Resolved persistent hypertension with personalized dietary and medication plan.',
    quote: 'The promptness and attention to detail at Medicare Plus changed my outlook on clinical care. Dr. Adebayo listened to every concern and within 6 weeks my vitals returned to healthy ranges.',
    rating: 5,
    date: 'October 2026'
  },
  {
    id: 't-2',
    name: 'Mrs. Folake Oshodi',
    role: 'Mother of twins, Maternity Care',
    outcome: 'Smooth antenatal journey and safe delivery under Dr. Sarah Jenkins.',
    quote: 'From my first ultrasound to delivery day, Medicare Plus provided reassuring guidance. The consultation rooms are spotless and the WhatsApp support team answered my urgent questions promptly.',
    rating: 5,
    date: 'September 2026'
  },
  {
    id: 't-3',
    name: 'Dr. Chinedu Ezeh',
    role: 'Parent, Paediatric Clinic',
    outcome: 'Immediate compassionate treatment for child respiratory infection.',
    quote: 'Finding a pediatrician who makes children feel calm is rare. Dr. Chioma was thorough, gentle, and explained the care plan clearly without over-prescribing medications.',
    rating: 5,
    date: 'October 2026'
  }
];
