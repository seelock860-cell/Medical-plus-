export const COMPLETE_SUPABASE_SQL_SCHEMA = `-- ==============================================================================
-- MEDICARE PLUS HEALTHCARE PLATFORM - SUPABASE DATABASE SCHEMA
-- Execute this script in your Supabase SQL Editor (Dashboard > SQL Editor > New Query)
-- ==============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. HEALTHCARE SERVICES TABLE
CREATE TABLE IF NOT EXISTS public.services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'General Care',
    short_description TEXT NOT NULL,
    full_description TEXT,
    icon_name TEXT DEFAULT 'Stethoscope',
    duration_minutes INTEGER DEFAULT 30,
    consultation_fee TEXT DEFAULT 'Contact Clinic',
    available_days TEXT[] DEFAULT ARRAY['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    features TEXT[] DEFAULT ARRAY[]::TEXT[],
    is_active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 3. DOCTORS TABLE
CREATE TABLE IF NOT EXISTS public.doctors (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    title TEXT NOT NULL,
    role TEXT NOT NULL,
    department TEXT NOT NULL,
    specializations TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
    qualifications TEXT NOT NULL,
    experience_years INTEGER NOT NULL DEFAULT 5,
    bio TEXT,
    photo_url TEXT,
    available_days TEXT[] DEFAULT ARRAY['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    is_available BOOLEAN NOT NULL DEFAULT true,
    phone TEXT,
    email TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 4. APPOINTMENTS TABLE
CREATE TABLE IF NOT EXISTS public.appointments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reference_code TEXT NOT NULL UNIQUE,
    patient_name TEXT NOT NULL,
    patient_phone TEXT NOT NULL,
    patient_email TEXT NOT NULL,
    service_id TEXT,
    service_name TEXT NOT NULL,
    doctor_id TEXT,
    doctor_name TEXT,
    appointment_date DATE NOT NULL,
    time_slot TEXT NOT NULL,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 5. SITE CONTENT CONFIGURATION TABLE
CREATE TABLE IF NOT EXISTS public.site_content (
    id TEXT PRIMARY KEY,
    data JSONB NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 6. ENABLE ROW LEVEL SECURITY (RLS)
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.doctors ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_content ENABLE ROW LEVEL SECURITY;

-- 7. RLS POLICIES FOR SERVICES
CREATE POLICY "Public services read access" 
ON public.services FOR SELECT 
USING (is_active = true OR auth.role() = 'authenticated');

CREATE POLICY "Admin services write access" 
ON public.services FOR ALL 
USING (auth.role() = 'authenticated')
WITH CHECK (auth.role() = 'authenticated');

-- 8. RLS POLICIES FOR DOCTORS
CREATE POLICY "Public doctors read access" 
ON public.doctors FOR SELECT 
USING (true);

CREATE POLICY "Admin doctors write access" 
ON public.doctors FOR ALL 
USING (auth.role() = 'authenticated')
WITH CHECK (auth.role() = 'authenticated');

-- 9. RLS POLICIES FOR APPOINTMENTS
CREATE POLICY "Public can book appointments" 
ON public.appointments FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Patients can view own appointment" 
ON public.appointments FOR SELECT 
USING (auth.role() = 'authenticated' OR reference_code IS NOT NULL);

CREATE POLICY "Admin appointments full access" 
ON public.appointments FOR ALL 
USING (auth.role() = 'authenticated')
WITH CHECK (auth.role() = 'authenticated');

-- 10. RLS POLICIES FOR SITE CONTENT
CREATE POLICY "Public can view site content" 
ON public.site_content FOR SELECT 
USING (true);

CREATE POLICY "Admin can update site content" 
ON public.site_content FOR ALL 
USING (auth.role() = 'authenticated')
WITH CHECK (auth.role() = 'authenticated');

-- 11. SEED DEFAULT HEALTHCARE SERVICES
INSERT INTO public.services (name, category, short_description, full_description, icon_name, duration_minutes, consultation_fee, available_days, features, is_active)
VALUES 
('General Consultation', 'Primary Care', 'Comprehensive medical assessment, preventive health screenings, and tailored therapy plans.', 'Our primary care physicians conduct comprehensive clinical check-ups, review medical histories, treat acute illnesses, and help manage long-term wellness.', 'Stethoscope', 30, '₦15,000 / $25', ARRAY['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], ARRAY['Thorough physical examination', 'Prescription & medication review', 'Preventative health roadmap'], true),
('Dental Care', 'Specialist Care', 'Advanced oral hygiene, restorative dentistry, painless extractions, and cosmetic orthodontics.', 'State-of-the-art dental clinic providing preventative cleanings, root canal therapy, digital dental X-rays, cavity fillings, and restorative smile enhancements.', 'Smile', 45, '₦20,000 / $35', ARRAY['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'], ARRAY['Ultrasonic tartar removal', 'Digital intraoral imaging', 'Painless tooth restorations'], true),
('Maternity Care', 'Women Health', 'Dedicated prenatal monitoring, safe delivery suites, and postnatal mother-baby support.', 'Compassionate maternal care for expectant mothers throughout pregnancy stages, including 4D ultrasound scans, genetic screening, delivery care, and lactation support.', 'HeartPulse', 45, '₦25,000 / $40', ARRAY['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], ARRAY['Routine obstetric ultrasonography', 'Maternal nutritional guidance', 'Postpartum healing reviews'], true),
('Paediatrics', 'Child Health', 'Specialised medical care for newborns, infants, children, and growing adolescents.', 'Child-friendly clinical environments designed to support immunization schedules, growth milestone evaluations, common childhood infection management, and pediatric wellness.', 'Baby', 30, '₦18,000 / $30', ARRAY['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], ARRAY['WHO immunization schedules', 'Developmental tracking', 'Pediatric allergy testing'], true),
('Laboratory and Diagnostics', 'Diagnostics', 'Fully automated pathology, microbiology, clinical biochemistry, and rapid result reporting.', 'Certified clinical diagnostic laboratory equipped with automated blood analyzers, digital microbiology, lipid profiles, hormonal assays, and same-day electronic result dispatch.', 'FlaskConical', 20, 'Varies by test', ARRAY['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], ARRAY['Complete blood count (CBC)', 'Organ function panels', 'Digital result portal'], true),
('Family Healthcare', 'Primary Care', 'Holistic health plans protecting every generation of your household under unified records.', 'Continuous, coordinated healthcare for multi-generational families. We manage hypertension, diabetes, seasonal illnesses, and routine annual wellness physicals for all ages.', 'Users', 45, '₦30,000 / $50', ARRAY['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'], ARRAY['Multi-member record management', 'Chronic disease monitoring', 'Senior citizen care packages'], true),
('Specialist Consultations', 'Specialist Care', 'Direct access to senior consultant cardiologists, neurologists, surgeons, and endocrinologists.', 'Collaborative care with certified medical specialists for complex diagnostics, second opinions, pre-operative evaluations, and specialized treatment strategies.', 'GraduationCap', 60, '₦35,000 / $60', ARRAY['Tuesday', 'Thursday', 'Saturday'], ARRAY['Sub-specialty diagnostic reviews', 'Comprehensive treatment roadmaps', 'Direct physician follow-up'], true)
ON CONFLICT DO NOTHING;
`;
