import React from 'react';
import { useApp } from '../context/AppContext';
import { ShieldCheck, Heart, Sparkles, Building2 } from 'lucide-react';

export const WelcomeSection: React.FC = () => {
  const { siteContent } = useApp();

  return (
    <section className="py-16 bg-slate-50 border-y border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="max-w-3xl mx-auto text-center space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider">
            <Building2 className="w-4 h-4 text-teal-600" />
            <span>Welcome to Medicare Plus</span>
          </div>
          
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
            {siteContent.welcomeTitle}
          </h2>
          
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            {siteContent.welcomeMessage}
          </p>

          <p className="text-sm font-medium text-slate-500 pt-2">
            {siteContent.welcomeSubtext}
          </p>
        </div>

        {/* 3 Pillars of Care */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <div className="bg-white p-7 rounded-2xl border border-slate-200 shadow-sm text-left">
            <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center text-teal-600 mb-5">
              <Heart className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Patient-Centred Philosophy</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              We treat individuals, not just symptoms. Every consultation is conducted with unhurried clinical attention, privacy, and thorough explanation of treatment options.
            </p>
          </div>

          <div className="bg-white p-7 rounded-2xl border border-slate-200 shadow-sm text-left">
            <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center text-slate-900 mb-5">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Precision Diagnostics</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Equipped with computerized pathology and high-resolution imaging, our laboratory ensures prompt, accurate testing so interventions start without delay.
            </p>
          </div>

          <div className="bg-white p-7 rounded-2xl border border-slate-200 shadow-sm text-left">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600 mb-5">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">Ethical & Transparent Care</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              From transparent consultation fees to secure patient health records, Medicare Plus adheres to the highest bioethical and safety standards.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
