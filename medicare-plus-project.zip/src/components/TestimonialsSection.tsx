import React from 'react';
import { TESTIMONIALS } from '../data/initialData';
import { MessageSquare, Star, ShieldCheck } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider mb-2">
            <MessageSquare className="w-4 h-4 text-teal-600" />
            <span>Verified Patient Experiences</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
            Real Stories of Recovery & Compassionate Care
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Read verified patient reflections from individuals and families who received clinical care at Medicare Plus.
          </p>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((item) => (
            <div
              key={item.id}
              className="bg-slate-50/70 rounded-2xl border border-slate-200/90 p-7 flex flex-col justify-between text-left shadow-xs hover:shadow-sm transition-all"
            >
              <div>
                {/* Star rating */}
                <div className="flex items-center gap-1 mb-4 text-amber-500">
                  {Array.from({ length: item.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                {/* Patient Quote */}
                <p className="text-sm text-slate-700 leading-relaxed italic">
                  "{item.quote}"
                </p>

                {/* Specific Outcome */}
                <div className="mt-4 pt-3 border-t border-slate-200/80 text-xs text-teal-800 font-medium">
                  <strong>Outcome:</strong> {item.outcome}
                </div>
              </div>

              {/* Author Info */}
              <div className="mt-6 pt-4 border-t border-slate-200/80 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{item.name}</h4>
                  <p className="text-slate-500">{item.role}</p>
                </div>
                <div className="flex items-center gap-1 text-[11px] text-teal-700 font-medium bg-teal-50 px-2 py-0.5 rounded">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Verified</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
