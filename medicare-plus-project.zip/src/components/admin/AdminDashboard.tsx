import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Appointment,
  AppointmentStatus,
  Doctor,
  MedicalService,
  SiteContent
} from '../../types';
import { COMPLETE_SUPABASE_SQL_SCHEMA } from '../../data/sqlSchema';
import {
  Shield,
  LayoutDashboard,
  CalendarCheck,
  UserCheck,
  Stethoscope,
  Globe,
  Database,
  LogOut,
  ArrowLeft,
  Search,
  Filter,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  XCircle,
  Clock,
  MessageSquare,
  Copy,
  ExternalLink,
  RefreshCw,
  AlertCircle,
  Save,
  Check,
  Upload,
  Download,
  FolderArchive,
  Terminal,
  FileCode
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    adminUser,
    isAdminLoggedIn,
    loginAdmin,
    logoutAdmin,
    setActiveView,
    appointments,
    updateAppointmentStatus,
    deleteAppointment,
    doctors,
    addDoctor,
    updateDoctor,
    deleteDoctor,
    services,
    addService,
    updateService,
    deleteService,
    siteContent,
    updateSiteContent,
    supabaseConfig,
    updateSupabaseConfig,
    testSupabaseConfig,
    showToast
  } = useApp();

  // Navigation tab inside admin
  const [activeTab, setActiveTab] = useState<
    'overview' | 'appointments' | 'doctors' | 'services' | 'content' | 'supabase' | 'deployment'
  >('overview');
  const [copiedGitCmd, setCopiedGitCmd] = useState(false);

  // Login form state
  const [loginUsername, setLoginUsername] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginLoading, setLoginLoading] = useState(false);

  // Appointments Filter & Search
  const [aptSearch, setAptSearch] = useState('');
  const [aptStatusFilter, setAptStatusFilter] = useState<string>('all');

  // Supabase Config form state
  const [sbUrl, setSbUrl] = useState(supabaseConfig.url || '');
  const [sbAnonKey, setSbAnonKey] = useState(supabaseConfig.anonKey || '');
  const [isTestingSb, setIsTestingSb] = useState(false);
  const [sbTestResult, setSbTestResult] = useState<{ success: boolean; message: string } | null>(null);

  // Doctors modal state
  const [doctorModalOpen, setDoctorModalOpen] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);
  const [docName, setDocName] = useState('');
  const [docTitle, setDocTitle] = useState('');
  const [docRole, setDocRole] = useState('');
  const [docDepartment, setDocDepartment] = useState('');
  const [docSpecializations, setDocSpecializations] = useState('');
  const [docQualifications, setDocQualifications] = useState('');
  const [docExperience, setDocExperience] = useState(5);
  const [docBio, setDocBio] = useState('');
  const [docPhotoUrl, setDocPhotoUrl] = useState('');
  const [docAvailable, setDocAvailable] = useState(true);

  // Services modal state
  const [serviceModalOpen, setServiceModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<MedicalService | null>(null);
  const [srvName, setSrvName] = useState('');
  const [srvCategory, setSrvCategory] = useState('Primary Care');
  const [srvShortDesc, setSrvShortDesc] = useState('');
  const [srvFullDesc, setSrvFullDesc] = useState('');
  const [srvFee, setSrvFee] = useState('');
  const [srvDuration, setSrvDuration] = useState(30);
  const [srvFeatures, setSrvFeatures] = useState('');
  const [srvActive, setSrvActive] = useState(true);

  // Site Content Form state
  const [contentForm, setContentForm] = useState<SiteContent>(siteContent);
  const [isSavingContent, setIsSavingContent] = useState(false);

  // SQL script copy state
  const [copiedSql, setCopiedSql] = useState(false);

  // Login handler
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);
    await loginAdmin(loginUsername, loginPassword);
    setLoginLoading(false);
  };

  // If not logged in, show secure admin login screen
  if (!isAdminLoggedIn) {
    return (
      <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-md">
          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 rounded-2xl bg-teal-500 flex items-center justify-center text-slate-900 shadow-xl">
              <Shield className="w-8 h-8" />
            </div>
          </div>
          <h2 className="text-center text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            MEDICARE <span className="text-teal-400">PLUS</span>
          </h2>
          <p className="mt-1 text-center text-xs text-slate-400">
            Hospital Administration & Supabase Portal
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-slate-800/90 py-8 px-6 shadow-2xl rounded-2xl sm:px-10 border border-slate-700">
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Admin Username or Email
                </label>
                <input
                  type="text"
                  required
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                  placeholder="Enter username or email"
                  className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-600 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Admin Password
                </label>
                <input
                  type="password"
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-600 rounded-lg text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500"
                />
              </div>

              <button
                type="submit"
                disabled={loginLoading}
                className="w-full py-2.5 px-4 text-xs font-bold text-slate-900 bg-teal-400 hover:bg-teal-300 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                {loginLoading ? (
                  <div className="w-4 h-4 border-2 border-slate-900 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Shield className="w-4 h-4" />
                    <span>Sign In as Hospital Administrator</span>
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 pt-4 border-t border-slate-700 text-center">
              <button
                onClick={() => setActiveView('public')}
                className="text-xs text-slate-400 hover:text-white transition-colors flex items-center justify-center gap-1 mx-auto"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Public Hospital Website</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Calculate Overview Metrics
  const totalAppointments = appointments.length;
  const pendingAppointments = appointments.filter((a) => a.status === 'pending').length;
  const confirmedAppointments = appointments.filter((a) => a.status === 'confirmed').length;
  const cancelledAppointments = appointments.filter((a) => a.status === 'cancelled').length;
  const completedAppointments = appointments.filter((a) => a.status === 'completed').length;

  // Filtered Appointments list
  const filteredAppointments = appointments.filter((apt) => {
    const matchesStatus = aptStatusFilter === 'all' || apt.status === aptStatusFilter;
    const query = aptSearch.toLowerCase().trim();
    const matchesSearch =
      !query ||
      apt.patientName.toLowerCase().includes(query) ||
      apt.referenceCode.toLowerCase().includes(query) ||
      apt.patientPhone.includes(query) ||
      apt.serviceName.toLowerCase().includes(query);
    return matchesStatus && matchesSearch;
  });

  // Doctor Modal openers
  const openNewDoctorModal = () => {
    setEditingDoctor(null);
    setDocName('');
    setDocTitle('');
    setDocRole('');
    setDocDepartment('General Medicine');
    setDocSpecializations('');
    setDocQualifications('');
    setDocExperience(5);
    setDocBio('');
    setDocPhotoUrl('/assets/images/doctor_adebayo_cmd_1793519705589.jpg');
    setDocAvailable(true);
    setDoctorModalOpen(true);
  };

  const openEditDoctorModal = (doc: Doctor) => {
    setEditingDoctor(doc);
    setDocName(doc.name);
    setDocTitle(doc.title);
    setDocRole(doc.role);
    setDocDepartment(doc.department);
    setDocSpecializations(doc.specializations.join(', '));
    setDocQualifications(doc.qualifications);
    setDocExperience(doc.experienceYears);
    setDocBio(doc.bio);
    setDocPhotoUrl(doc.photoUrl);
    setDocAvailable(doc.isAvailable);
    setDoctorModalOpen(true);
  };

  const handleSaveDoctor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docName.trim() || !docTitle.trim()) {
      showToast('Doctor name and title are required.', 'error');
      return;
    }

    const specs = docSpecializations
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    if (editingDoctor) {
      await updateDoctor(editingDoctor.id, {
        name: docName.trim(),
        title: docTitle.trim(),
        role: docRole.trim() || docTitle.trim(),
        department: docDepartment.trim(),
        specializations: specs.length ? specs : ['General Consultation'],
        qualifications: docQualifications.trim(),
        experienceYears: Number(docExperience),
        bio: docBio.trim(),
        photoUrl: docPhotoUrl.trim() || '/assets/images/doctor_adebayo_cmd_1793519705589.jpg',
        isAvailable: docAvailable
      });
    } else {
      await addDoctor({
        name: docName.trim(),
        title: docTitle.trim(),
        role: docRole.trim() || docTitle.trim(),
        department: docDepartment.trim(),
        specializations: specs.length ? specs : ['General Consultation'],
        qualifications: docQualifications.trim(),
        experienceYears: Number(docExperience),
        bio: docBio.trim(),
        photoUrl: docPhotoUrl.trim() || '/src/assets/images/doctor_adebayo_cmd_1793519705589.jpg',
        availableDays: ['Monday', 'Wednesday', 'Friday'],
        isAvailable: docAvailable
      });
    }

    setDoctorModalOpen(false);
  };

  // Service Modal Openers
  const openNewServiceModal = () => {
    setEditingService(null);
    setSrvName('');
    setSrvCategory('Primary Care');
    setSrvShortDesc('');
    setSrvFullDesc('');
    setSrvFee('₦15,000 / $25');
    setSrvDuration(30);
    setSrvFeatures('');
    setSrvActive(true);
    setServiceModalOpen(true);
  };

  const openEditServiceModal = (srv: MedicalService) => {
    setEditingService(srv);
    setSrvName(srv.name);
    setSrvCategory(srv.category);
    setSrvShortDesc(srv.shortDescription);
    setSrvFullDesc(srv.fullDescription);
    setSrvFee(srv.consultationFee);
    setSrvDuration(srv.durationMinutes);
    setSrvFeatures(srv.features.join(', '));
    setSrvActive(srv.isActive);
    setServiceModalOpen(true);
  };

  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!srvName.trim() || !srvShortDesc.trim()) {
      showToast('Service name and description are required.', 'error');
      return;
    }

    const feats = srvFeatures
      .split(',')
      .map((f) => f.trim())
      .filter(Boolean);

    if (editingService) {
      await updateService(editingService.id, {
        name: srvName.trim(),
        category: srvCategory.trim(),
        shortDescription: srvShortDesc.trim(),
        fullDescription: srvFullDesc.trim() || srvShortDesc.trim(),
        consultationFee: srvFee.trim(),
        durationMinutes: Number(srvDuration),
        features: feats,
        isActive: srvActive
      });
    } else {
      await addService({
        name: srvName.trim(),
        category: srvCategory.trim(),
        shortDescription: srvShortDesc.trim(),
        fullDescription: srvFullDesc.trim() || srvShortDesc.trim(),
        iconName: 'Stethoscope',
        consultationFee: srvFee.trim(),
        durationMinutes: Number(srvDuration),
        availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
        features: feats,
        isActive: srvActive
      });
    }

    setServiceModalOpen(false);
  };

  // Save Website Content
  const handleSaveContent = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingContent(true);
    await updateSiteContent(contentForm);
    setIsSavingContent(false);
  };

  // Supabase test and update
  const handleTestSupabase = async () => {
    setIsTestingSb(true);
    setSbTestResult(null);
    const res = await testSupabaseConfig(sbUrl, sbAnonKey);
    setSbTestResult(res);
    setIsTestingSb(false);
  };

  const handleSaveSupabase = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsTestingSb(true);
    const res = await updateSupabaseConfig(sbUrl, sbAnonKey);
    setSbTestResult(res);
    setIsTestingSb(false);
  };

  const copySqlSchema = () => {
    navigator.clipboard.writeText(COMPLETE_SUPABASE_SQL_SCHEMA);
    setCopiedSql(true);
    showToast('Full Supabase SQL schema copied to clipboard!');
    setTimeout(() => setCopiedSql(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 text-left flex flex-col">
      
      {/* Admin Top Header */}
      <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveView('public')}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition-colors"
              title="Return to Public Website"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold tracking-tight text-white">
                MEDICARE <span className="text-teal-400">PLUS</span>
              </span>
              <span className="text-[11px] font-semibold bg-teal-950 text-teal-300 px-2 py-0.5 rounded border border-teal-800">
                ADMIN CONSOLE
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Supabase Status Pill */}
            <div className="hidden sm:flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-md bg-slate-800 border border-slate-700">
              <Database className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-400">Database:</span>
              {supabaseConfig.isConnected ? (
                <span className="text-teal-400 font-semibold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-teal-400" /> Supabase Live
                </span>
              ) : (
                <span className="text-amber-400 font-semibold flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-400" /> Local/Pending
                </span>
              )}
            </div>

            <div className="text-xs text-slate-300 hidden md:block">
              Logged in as <strong className="text-white font-mono">{adminUser?.username}</strong>
            </div>

            <a
              href="/medicare-plus-project.zip"
              download="medicare-plus-project.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-teal-300 hover:text-white bg-teal-950/60 hover:bg-teal-900/80 rounded-lg border border-teal-700 transition-colors"
              title="Download all source files as a ZIP archive for GitHub and Vercel"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download ZIP (All Files)</span>
            </a>

            <button
              onClick={logoutAdmin}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-300 hover:text-white bg-rose-950/40 hover:bg-rose-900/60 rounded-lg border border-rose-800 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Log Out</span>
            </button>
          </div>

        </div>

        {/* Tab Navigation */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex overflow-x-auto gap-1 border-t border-slate-800/80">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-2 ${
              activeTab === 'overview'
                ? 'border-teal-400 text-teal-300 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard Overview</span>
          </button>

          <button
            onClick={() => setActiveTab('appointments')}
            className={`px-4 py-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-2 ${
              activeTab === 'appointments'
                ? 'border-teal-400 text-teal-300 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <CalendarCheck className="w-4 h-4" />
            <span>Appointments ({pendingAppointments} Pending)</span>
          </button>

          <button
            onClick={() => setActiveTab('doctors')}
            className={`px-4 py-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-2 ${
              activeTab === 'doctors'
                ? 'border-teal-400 text-teal-300 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Doctor Management</span>
          </button>

          <button
            onClick={() => setActiveTab('services')}
            className={`px-4 py-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-2 ${
              activeTab === 'services'
                ? 'border-teal-400 text-teal-300 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Stethoscope className="w-4 h-4" />
            <span>Healthcare Services</span>
          </button>

          <button
            onClick={() => setActiveTab('content')}
            className={`px-4 py-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-2 ${
              activeTab === 'content'
                ? 'border-teal-400 text-teal-300 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>Website Content</span>
          </button>

          <button
            onClick={() => setActiveTab('supabase')}
            className={`px-4 py-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-2 ${
              activeTab === 'supabase'
                ? 'border-teal-400 text-teal-300 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Supabase Settings</span>
          </button>

          <button
            onClick={() => setActiveTab('deployment')}
            className={`px-4 py-3 text-xs font-semibold whitespace-nowrap transition-colors border-b-2 flex items-center gap-2 ${
              activeTab === 'deployment'
                ? 'border-teal-400 text-teal-300 bg-slate-800/50'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderArchive className="w-4 h-4" />
            <span className="font-bold text-amber-300">GitHub & Vercel Upload</span>
          </button>
        </div>
      </header>

      {/* Main Admin Content Body */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1">
        
        {/* ========================================================================= */}
        {/* TAB 1: OVERVIEW */}
        {/* ========================================================================= */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            
            {/* Stat Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              
              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-500 mb-2">
                  <span className="text-xs font-semibold uppercase">Total Requests</span>
                  <CalendarCheck className="w-5 h-5 text-slate-700" />
                </div>
                <div className="text-3xl font-extrabold text-slate-900 tabular-nums">
                  {totalAppointments}
                </div>
                <p className="text-[11px] text-slate-500 mt-1">All clinical patient submissions</p>
              </div>

              <div className="bg-white rounded-xl p-5 border border-amber-200 bg-amber-50/20 shadow-xs">
                <div className="flex items-center justify-between text-amber-700 mb-2">
                  <span className="text-xs font-semibold uppercase">Pending Triage</span>
                  <Clock className="w-5 h-5 text-amber-600" />
                </div>
                <div className="text-3xl font-extrabold text-amber-700 tabular-nums">
                  {pendingAppointments}
                </div>
                <p className="text-[11px] text-amber-700/80 mt-1">Requires confirmation call / text</p>
              </div>

              <div className="bg-white rounded-xl p-5 border border-teal-200 bg-teal-50/20 shadow-xs">
                <div className="flex items-center justify-between text-teal-700 mb-2">
                  <span className="text-xs font-semibold uppercase">Confirmed Slots</span>
                  <CheckCircle className="w-5 h-5 text-teal-600" />
                </div>
                <div className="text-3xl font-extrabold text-teal-700 tabular-nums">
                  {confirmedAppointments}
                </div>
                <p className="text-[11px] text-teal-700/80 mt-1">Scheduled on doctor rosters</p>
              </div>

              <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-slate-500 mb-2">
                  <span className="text-xs font-semibold uppercase">Cancelled / Completed</span>
                  <XCircle className="w-5 h-5 text-slate-400" />
                </div>
                <div className="text-3xl font-extrabold text-slate-800 tabular-nums">
                  {completedAppointments} <span className="text-sm font-normal text-slate-400">/ {cancelledAppointments}</span>
                </div>
                <p className="text-[11px] text-slate-500 mt-1">Completed vs cancelled records</p>
              </div>

            </div>

            {/* Quick Actions & Recent Appointments Split */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Recent Appointments Preview */}
              <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 shadow-xs p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-base font-bold text-slate-900">Recent Appointment Requests</h3>
                  <button
                    onClick={() => setActiveTab('appointments')}
                    className="text-xs font-semibold text-teal-600 hover:text-teal-700"
                  >
                    View All ({appointments.length})
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-500 uppercase border-y border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Ref</th>
                        <th className="py-2.5 px-3">Patient</th>
                        <th className="py-2.5 px-3">Department</th>
                        <th className="py-2.5 px-3">Date & Slot</th>
                        <th className="py-2.5 px-3">Status</th>
                        <th className="py-2.5 px-3 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {appointments.slice(0, 5).map((apt) => (
                        <tr key={apt.id} className="hover:bg-slate-50/50">
                          <td className="py-3 px-3 font-mono font-semibold text-teal-700">
                            {apt.referenceCode}
                          </td>
                          <td className="py-3 px-3">
                            <p className="font-semibold text-slate-900">{apt.patientName}</p>
                            <p className="text-slate-500 text-[11px]">{apt.patientPhone}</p>
                          </td>
                          <td className="py-3 px-3 text-slate-700">{apt.serviceName}</td>
                          <td className="py-3 px-3 text-slate-600">
                            <p className="font-medium">{apt.appointmentDate}</p>
                            <p className="text-[11px] text-slate-400">{apt.timeSlot}</p>
                          </td>
                          <td className="py-3 px-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                apt.status === 'confirmed'
                                  ? 'bg-teal-100 text-teal-800'
                                  : apt.status === 'pending'
                                  ? 'bg-amber-100 text-amber-800'
                                  : apt.status === 'completed'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {apt.status}
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right">
                            <button
                              onClick={() => {
                                setActiveTab('appointments');
                                setAptSearch(apt.referenceCode);
                              }}
                              className="text-xs text-teal-600 hover:text-teal-800 font-semibold"
                            >
                              Manage
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Quick Admin Summary & WhatsApp Hotline */}
              <div className="lg:col-span-4 space-y-6">
                
                <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs space-y-4">
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">Quick Controls</h3>
                  
                  <button
                    onClick={openNewDoctorModal}
                    className="w-full py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4 text-teal-400" />
                    <span>Add New Doctor Profile</span>
                  </button>

                  <button
                    onClick={openNewServiceModal}
                    className="w-full py-2.5 px-3 bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4 text-teal-600" />
                    <span>Add Healthcare Service</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('supabase')}
                    className="w-full py-2.5 px-3 bg-teal-50 hover:bg-teal-100 border border-teal-200 text-teal-800 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <Database className="w-4 h-4 text-teal-600" />
                    <span>Configure Supabase Connection</span>
                  </button>
                </div>

                <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-xl p-6 shadow-sm space-y-3">
                  <div className="flex items-center gap-2 text-teal-400 text-xs font-bold uppercase">
                    <MessageSquare className="w-4 h-4" />
                    <span>Admin WhatsApp Hotline</span>
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Default hospital triage number: <strong className="text-white">{siteContent.whatsappNumber}</strong>. 
                    You can initiate direct WhatsApp conversations with booked patients from the Appointments tab.
                  </p>
                </div>

              </div>

            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: APPOINTMENTS MANAGEMENT */}
        {/* ========================================================================= */}
        {activeTab === 'appointments' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Appointment Requests Management</h3>
                <p className="text-xs text-slate-500">
                  Review incoming requests, confirm time slots, send direct WhatsApp notifications, or adjust appointment status.
                </p>
              </div>

              {/* Status Filter Buttons */}
              <div className="flex flex-wrap items-center gap-1.5">
                {['all', 'pending', 'confirmed', 'completed', 'cancelled'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setAptStatusFilter(st)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg capitalize transition-colors ${
                      aptStatusFilter === st
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {/* Search Bar */}
            <div className="relative">
              <Search className="w-4 h-4 absolute inset-y-0 left-3 my-auto text-slate-400" />
              <input
                type="text"
                value={aptSearch}
                onChange={(e) => setAptSearch(e.target.value)}
                placeholder="Search by patient name, reference code (e.g. MCP-84920), phone number, or department..."
                className="w-full pl-9 pr-4 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
              />
            </div>

            {/* Appointments Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-bold uppercase border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Reference</th>
                    <th className="py-3 px-4">Patient Info</th>
                    <th className="py-3 px-4">Service & Doctor</th>
                    <th className="py-3 px-4">Scheduled Slot</th>
                    <th className="py-3 px-4">Notes / Reason</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAppointments.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-8 text-slate-400">
                        No appointments found matching your search criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredAppointments.map((apt) => (
                      <tr key={apt.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3.5 px-4 font-mono font-bold text-teal-700 whitespace-nowrap">
                          {apt.referenceCode}
                        </td>
                        <td className="py-3.5 px-4">
                          <p className="font-bold text-slate-900">{apt.patientName}</p>
                          <p className="text-slate-500 text-[11px]">{apt.patientPhone}</p>
                          <p className="text-slate-400 text-[10px]">{apt.patientEmail}</p>
                        </td>
                        <td className="py-3.5 px-4">
                          <p className="font-semibold text-slate-800">{apt.serviceName}</p>
                          <p className="text-slate-500 text-[11px]">{apt.doctorName || 'Any Specialist'}</p>
                        </td>
                        <td className="py-3.5 px-4 whitespace-nowrap">
                          <p className="font-medium text-slate-900">{apt.appointmentDate}</p>
                          <p className="text-slate-500 text-[11px]">{apt.timeSlot}</p>
                        </td>
                        <td className="py-3.5 px-4 max-w-xs truncate text-slate-600">
                          {apt.notes || <span className="text-slate-300 italic">None provided</span>}
                        </td>
                        <td className="py-3.5 px-4">
                          <span
                            className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase ${
                              apt.status === 'confirmed'
                                ? 'bg-teal-100 text-teal-800'
                                : apt.status === 'pending'
                                ? 'bg-amber-100 text-amber-800'
                                : apt.status === 'completed'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {apt.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            
                            {/* WhatsApp Patient Button */}
                            <a
                              href={`https://wa.me/234${apt.patientPhone.replace(/^0+/, '').replace(/\D/g, '')}?text=${encodeURIComponent(
                                `Hello ${apt.patientName}, this is Medicare Plus Hospital regarding your appointment request ${apt.referenceCode} for ${apt.serviceName} on ${apt.appointmentDate} at ${apt.timeSlot}.`
                              )}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              title="Chat with patient on WhatsApp"
                              className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded border border-emerald-200 transition-colors"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </a>

                            {/* Confirm Action */}
                            {apt.status !== 'confirmed' && (
                              <button
                                onClick={() => updateAppointmentStatus(apt.id, 'confirmed')}
                                title="Mark Confirmed"
                                className="px-2 py-1 bg-teal-50 hover:bg-teal-100 text-teal-700 rounded border border-teal-200 font-semibold"
                              >
                                Confirm
                              </button>
                            )}

                            {/* Complete Action */}
                            {apt.status === 'confirmed' && (
                              <button
                                onClick={() => updateAppointmentStatus(apt.id, 'completed')}
                                title="Mark Completed"
                                className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded border border-blue-200 font-semibold"
                              >
                                Complete
                              </button>
                            )}

                            {/* Cancel Action */}
                            {apt.status !== 'cancelled' && (
                              <button
                                onClick={() => updateAppointmentStatus(apt.id, 'cancelled')}
                                title="Cancel Appointment"
                                className="px-2 py-1 bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700 rounded font-semibold"
                              >
                                Cancel
                              </button>
                            )}

                            {/* Delete Button */}
                            <button
                              onClick={() => {
                                if (window.confirm(`Delete record for ${apt.patientName} (${apt.referenceCode})?`)) {
                                  deleteAppointment(apt.id);
                                }
                              }}
                              title="Delete permanently"
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>

                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 3: DOCTOR MANAGEMENT */}
        {/* ========================================================================= */}
        {activeTab === 'doctors' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Hospital Medical Doctors</h3>
                <p className="text-xs text-slate-500">
                  Add, edit, upload photos, and manage medical specialisations and clinical availability.
                </p>
              </div>

              <button
                onClick={openNewDoctorModal}
                className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg flex items-center gap-2 cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Add Doctor</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {doctors.map((doctor) => (
                <div
                  key={doctor.id}
                  className="bg-slate-50/60 rounded-xl border border-slate-200 p-5 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start gap-4 mb-4">
                      <img
                        src={doctor.photoUrl}
                        alt={doctor.name}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 rounded-xl object-cover border border-slate-200 shadow-xs shrink-0"
                      />
                      <div className="text-left overflow-hidden">
                        <span className="text-[10px] font-bold uppercase text-teal-700">{doctor.department}</span>
                        <h4 className="text-sm font-bold text-slate-900 truncate">{doctor.name}</h4>
                        <p className="text-xs text-slate-500 truncate">{doctor.title}</p>
                        <p className="text-[11px] text-slate-600 mt-1">{doctor.qualifications}</p>
                      </div>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 mb-3">{doctor.bio}</p>

                    <div className="flex flex-wrap gap-1 mb-4">
                      {doctor.specializations.map((spec, i) => (
                        <span key={i} className="text-[10px] bg-white border border-slate-200 text-slate-700 px-1.5 py-0.5 rounded">
                          {spec}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-600">
                      {doctor.experienceYears} yrs experience
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openEditDoctorModal(doctor)}
                        className="p-1.5 text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 rounded border border-slate-200 transition-colors"
                        title="Edit Doctor"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`Delete profile for ${doctor.name}?`)) {
                            deleteDoctor(doctor.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 bg-white hover:bg-rose-50 rounded border border-slate-200 transition-colors"
                        title="Delete Doctor"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 4: HEALTHCARE SERVICES MANAGEMENT */}
        {/* ========================================================================= */}
        {activeTab === 'services' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900">Healthcare Services Management</h3>
                <p className="text-xs text-slate-500">
                  Manage the 7 primary healthcare services, consultation fees, and public visibility.
                </p>
              </div>

              <button
                onClick={openNewServiceModal}
                className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg flex items-center gap-2 cursor-pointer shadow-xs whitespace-nowrap self-start sm:self-auto"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Service</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {services.map((service) => (
                <div
                  key={service.id}
                  className={`bg-slate-50/70 rounded-xl border p-5 flex flex-col justify-between ${
                    service.isActive ? 'border-slate-200' : 'border-dashed border-slate-300 opacity-60'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-bold uppercase text-teal-700">{service.category}</span>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          service.isActive ? 'bg-teal-100 text-teal-800' : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {service.isActive ? 'Active' : 'Draft'}
                      </span>
                    </div>

                    <h4 className="text-base font-bold text-slate-900">{service.name}</h4>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-2">{service.shortDescription}</p>

                    <div className="mt-3 text-xs text-slate-700">
                      <span className="font-semibold text-slate-900">Fee:</span> {service.consultationFee} · ~{service.durationMinutes} mins
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between">
                    <button
                      onClick={() => updateService(service.id, { isActive: !service.isActive })}
                      className="text-xs text-slate-500 hover:text-slate-800 underline"
                    >
                      {service.isActive ? 'Deactivate' : 'Activate'}
                    </button>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openEditServiceModal(service)}
                        className="p-1.5 text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 rounded border border-slate-200 transition-colors"
                        title="Edit Service"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`Delete service ${service.name}?`)) {
                            deleteService(service.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 bg-white hover:bg-rose-50 rounded border border-slate-200 transition-colors"
                        title="Delete Service"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 5: WEBSITE CONTENT MANAGEMENT */}
        {/* ========================================================================= */}
        {activeTab === 'content' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-6 max-w-4xl">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Website Content Management</h3>
              <p className="text-xs text-slate-500">
                Update hospital copy, welcome messages, emergency notices, and telephone numbers across the platform.
              </p>
            </div>

            <form onSubmit={handleSaveContent} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Hospital / Platform Name</label>
                  <input
                    type="text"
                    value={contentForm.hospitalName}
                    onChange={(e) => setContentForm({ ...contentForm, hospitalName: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Tagline</label>
                  <input
                    type="text"
                    value={contentForm.tagline}
                    onChange={(e) => setContentForm({ ...contentForm, tagline: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Welcome Section Headline</label>
                <input
                  type="text"
                  value={contentForm.welcomeTitle}
                  onChange={(e) => setContentForm({ ...contentForm, welcomeTitle: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Welcome Section Message</label>
                <textarea
                  rows={3}
                  value={contentForm.welcomeMessage}
                  onChange={(e) => setContentForm({ ...contentForm, welcomeMessage: e.target.value })}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600 resize-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">WhatsApp Number (Requirement: 09024971419)</label>
                  <input
                    type="text"
                    value={contentForm.whatsappNumber}
                    onChange={(e) => setContentForm({ ...contentForm, whatsappNumber: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Official Hospital Telephone</label>
                  <input
                    type="text"
                    value={contentForm.phone}
                    onChange={(e) => setContentForm({ ...contentForm, phone: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Official Email</label>
                  <input
                    type="email"
                    value={contentForm.email}
                    onChange={(e) => setContentForm({ ...contentForm, email: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Consultation Hours</label>
                  <input
                    type="text"
                    value={contentForm.workingHours}
                    onChange={(e) => setContentForm({ ...contentForm, workingHours: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Physical Address</label>
                <input
                  type="text"
                  value={contentForm.address}
                  onChange={(e) => setContentForm({ ...contentForm, address: e.target.value })}
                  className="w-full px-3.5 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Emergency Medical Notice Disclaimer</label>
                <textarea
                  rows={2}
                  value={contentForm.emergencyNotice}
                  onChange={(e) => setContentForm({ ...contentForm, emergencyNotice: e.target.value })}
                  className="w-full p-3 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600 resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={isSavingContent}
                className="py-2.5 px-6 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Save className="w-4 h-4 text-teal-400" />
                <span>Save All Content Updates</span>
              </button>
            </form>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 6: SUPABASE INTEGRATION */}
        {/* ========================================================================= */}
        {activeTab === 'supabase' && (
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-6 space-y-8 max-w-4xl">
            
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
                <Database className="w-4 h-4 text-teal-600" />
                <span>Cloud Database Integration</span>
              </div>
              <h3 className="text-xl font-bold text-slate-900">Supabase Configuration & Status</h3>
              <p className="text-xs text-slate-500 mt-1">
                Connect MEDICARE PLUS to your own Supabase project. All appointments, doctors, services, and content sync directly with Row Level Security.
              </p>
            </div>

            {/* Connection Status Indicator Box */}
            <div className={`p-4 rounded-xl border flex items-start justify-between gap-4 ${
              supabaseConfig.isConnected ? 'bg-teal-50 border-teal-200' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                  supabaseConfig.isConnected ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-600'
                }`}>
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    Connection Status:{' '}
                    {supabaseConfig.isConnected ? (
                      <span className="text-teal-700">CONNECTED & VERIFIED</span>
                    ) : (
                      <span className="text-amber-600">NOT CONNECTED (LOCAL FALLBACK ACTIVE)</span>
                    )}
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {supabaseConfig.isConnected
                      ? `Project connected at: ${supabaseConfig.url}`
                      : 'The platform is currently operating in offline-first mode with full localStorage persistence. Enter your Supabase credentials below to connect to your live project.'}
                  </p>
                  {supabaseConfig.lastTestedAt && (
                    <p className="text-[11px] text-slate-400 mt-1">
                      Last verified: {new Date(supabaseConfig.lastTestedAt).toLocaleString()}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Supabase Configuration Form */}
            <form onSubmit={handleSaveSupabase} className="space-y-5">
              
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Supabase Project URL <span className="text-rose-500">*</span>
                </label>
                <input
                  type="url"
                  required
                  value={sbUrl}
                  onChange={(e) => setSbUrl(e.target.value)}
                  placeholder="https://xyzprojectid.supabase.co"
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-lg font-mono focus:outline-none focus:border-teal-600"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Found in your Supabase Dashboard &gt; Project Settings &gt; API &gt; Project URL.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Supabase Publishable / Anon Key <span className="text-rose-500">*</span>
                </label>
                <input
                  type="password"
                  required
                  value={sbAnonKey}
                  onChange={(e) => setSbAnonKey(e.target.value)}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-lg font-mono focus:outline-none focus:border-teal-600"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Found under Project Settings &gt; API &gt; Project API keys &gt; <strong className="text-slate-600 font-mono">anon public</strong>. Never enter your service_role secret key.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleTestSupabase}
                  disabled={isTestingSb || !sbUrl || !sbAnonKey}
                  className="py-2.5 px-4 text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isTestingSb ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <CheckCircle className="w-3.5 h-3.5 text-teal-600" />
                  )}
                  <span>Test Connection</span>
                </button>

                <button
                  type="submit"
                  disabled={isTestingSb || !sbUrl || !sbAnonKey}
                  className="py-2.5 px-5 text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors flex items-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save & Connect Supabase</span>
                </button>
              </div>

              {/* Test Result Feedback */}
              {sbTestResult && (
                <div
                  className={`p-3.5 rounded-lg border text-xs flex items-start gap-2.5 ${
                    sbTestResult.success
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : 'bg-rose-50 border-rose-200 text-rose-800'
                  }`}
                >
                  {sbTestResult.success ? (
                    <Check className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                  )}
                  <div>{sbTestResult.message}</div>
                </div>
              )}

            </form>

            {/* SQL Database Schema Setup Instructions */}
            <div className="pt-6 border-t border-slate-200 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Supabase SQL Schema & RLS Setup Script</h4>
                  <p className="text-xs text-slate-500">
                    Run this script in your Supabase SQL Editor to automatically provision tables (`services`, `doctors`, `appointments`, `site_content`) with Row Level Security.
                  </p>
                </div>
                <button
                  onClick={copySqlSchema}
                  className="px-3 py-1.5 text-xs font-semibold bg-slate-900 text-white rounded-lg hover:bg-slate-800 flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Copy className="w-3.5 h-3.5 text-teal-400" />
                  <span>{copiedSql ? 'Copied SQL!' : 'Copy SQL Script'}</span>
                </button>
              </div>

              <div className="bg-slate-900 text-slate-200 rounded-xl p-4 font-mono text-xs overflow-x-auto max-h-56 border border-slate-800">
                <pre>{COMPLETE_SUPABASE_SQL_SCHEMA}</pre>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-600 space-y-1">
                <p className="font-semibold text-slate-800">Deployment Steps:</p>
                <ol className="list-decimal list-inside space-y-0.5 text-slate-600">
                  <li>Create a free project at <a href="https://supabase.com" target="_blank" rel="noopener noreferrer" className="text-teal-600 underline font-medium">supabase.com</a></li>
                  <li>Go to <strong>SQL Editor</strong>, paste the content of <strong className="font-mono">/supabase/schema.sql</strong> and click <strong>Run</strong></li>
                  <li>Copy your <strong>Project URL</strong> and <strong>Anon Key</strong> into the fields above and click <strong>Save & Connect</strong></li>
                </ol>
              </div>

            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* TAB 7: GITHUB & VERCEL DEPLOYMENT HELPER */}
        {/* ========================================================================= */}
        {activeTab === 'deployment' && (
          <div className="space-y-6">
            
            {/* Diagnosis Banner for User's Screenshot */}
            <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-6 text-amber-950 shadow-xs">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-amber-200 text-amber-900 flex items-center justify-center shrink-0">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-base font-bold text-amber-950">
                    Why your GitHub only shows "Medical plus" (1 file) & Why Vercel Failed
                  </h3>
                  <p className="text-xs text-amber-900 leading-relaxed">
                    In your screenshot on GitHub (<code className="font-mono bg-amber-200/70 px-1.5 py-0.5 rounded font-bold">seelock860-cell/Medical-plus-</code>), only a single document icon named <code className="font-mono bg-amber-200/70 px-1.5 py-0.5 rounded font-bold">📄 Medical plus</code> was uploaded.
                  </p>
                  <p className="text-xs text-amber-900 leading-relaxed">
                    Mobile browsers cannot upload folders or complex directory structures. Because of this, GitHub is missing <strong className="font-mono">package.json</strong>, <strong className="font-mono">index.html</strong>, and the entire <strong className="font-mono">src/</strong> folder containing <strong className="font-mono">src/main.tsx</strong>. When Vercel tries to build, it can&apos;t find your code, resulting in <span className="font-mono text-rose-700 bg-rose-100 px-1 rounded font-semibold">Failed to resolve /src/main.tsx</span>.
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Download Card */}
            <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
                <div>
                  <span className="text-[10px] font-bold text-teal-700 uppercase tracking-widest bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                    Step 1: Download All Files
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 mt-1">Download Complete Medicare Plus Package</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Contains all 42 files including <code className="font-mono">src/</code>, <code className="font-mono">public/</code>, <code className="font-mono">package.json</code>, <code className="font-mono">vercel.json</code>, and your Supabase SQL scripts.
                  </p>
                </div>

                <a
                  href="/medicare-plus-project.zip"
                  download="medicare-plus-project.zip"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-bold rounded-xl shadow-md transition-all shrink-0 cursor-pointer"
                >
                  <Download className="w-5 h-5" />
                  <span>Download Project ZIP (7.1 MB)</span>
                </a>
              </div>

              {/* Upload Methods */}
              <div className="pt-6 space-y-6">
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                  Step 2: Upload to GitHub (<span className="font-mono text-teal-600">seelock860-cell/Medical-plus-</span>)
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Method A: In-Browser Editor (Recommended) */}
                  <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-teal-600 text-white font-bold text-xs flex items-center justify-center">A</span>
                      <h5 className="font-bold text-slate-900 text-sm">Web Browser Editor (Easiest)</h5>
                    </div>
                    <ol className="text-xs text-slate-600 space-y-2 list-decimal list-inside leading-relaxed">
                      <li>Extract the downloaded <code className="font-mono bg-white px-1 border rounded">medicare-plus-project.zip</code> on your computer.</li>
                      <li>
                        Open your repository in GitHub Web Editor by visiting:{' '}
                        <a
                          href="https://github.dev/seelock860-cell/Medical-plus-"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-teal-600 font-semibold underline inline-flex items-center gap-1"
                        >
                          github.dev/seelock860-cell/Medical-plus- <ExternalLink className="w-3 h-3" />
                        </a>
                      </li>
                      <li>Delete the old <code className="font-mono bg-white px-1 border rounded">Medical plus</code> placeholder file.</li>
                      <li>Drag and drop the unzipped project folder contents into the left-hand files panel.</li>
                      <li>Click the <strong>Source Control</strong> icon on the left, type <code className="font-mono">&quot;Initial project commit&quot;</code> and click <strong>Commit & Push</strong>.</li>
                    </ol>
                  </div>

                  {/* Method B: Terminal Git Commands */}
                  <div className="p-5 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-full bg-slate-800 text-white font-bold text-xs flex items-center justify-center">B</span>
                        <h5 className="font-bold text-slate-900 text-sm">Terminal Git (Fastest for Developers)</h5>
                      </div>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(
                            `# 1. Unzip the file and enter directory\ncd medicare-plus-project\n\n# 2. Initialize and link to your repo\ngit init\ngit branch -M main\ngit remote add origin https://github.com/seelock860-cell/Medical-plus-.git\n\n# 3. Add all files and push\ngit add .\ngit commit -m "Upload complete Medicare Plus platform"\ngit push -u origin main --force`
                          );
                          setCopiedGitCmd(true);
                          setTimeout(() => setCopiedGitCmd(false), 2000);
                        }}
                        className="px-2.5 py-1 text-[11px] font-semibold bg-slate-900 text-white rounded hover:bg-slate-800 flex items-center gap-1"
                      >
                        <Copy className="w-3 h-3 text-teal-400" />
                        <span>{copiedGitCmd ? 'Copied Commands!' : 'Copy Commands'}</span>
                      </button>
                    </div>

                    <div className="bg-slate-900 text-slate-200 p-3 rounded-lg font-mono text-[11px] overflow-x-auto space-y-1">
                      <p className="text-slate-400"># After unzipping in a folder:</p>
                      <p className="text-teal-300">git init</p>
                      <p className="text-teal-300">git remote add origin https://github.com/seelock860-cell/Medical-plus-.git</p>
                      <p className="text-teal-300">git branch -M main</p>
                      <p className="text-teal-300">git add .</p>
                      <p className="text-teal-300">git commit -m &quot;Upload complete Medicare Plus files&quot;</p>
                      <p className="text-teal-300">git push -u origin main --force</p>
                    </div>
                  </div>

                </div>

                {/* Vercel Outcome */}
                <div className="p-4 bg-teal-50 border border-teal-200 rounded-xl flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                  <div className="text-xs text-teal-950 space-y-1">
                    <p className="font-bold">Automatic Vercel Build:</p>
                    <p className="text-teal-900">
                      Because your repository is already linked to Vercel at <strong className="font-mono">medical-plus-psi.vercel.app</strong>, the moment your files arrive on GitHub, Vercel will automatically start a new build, compile Vite, and deploy your live healthcare platform in under 60 seconds!
                    </p>
                  </div>
                </div>

              </div>
            </div>

          </div>
        )}

      </main>

      {/* Doctor Create / Edit Modal */}
      {doctorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto text-left">
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              {editingDoctor ? 'Edit Doctor Profile' : 'Add New Doctor'}
            </h3>
            <p className="text-xs text-slate-500 mb-5">
              Fill in doctor credentials, clinical department, and photograph.
            </p>

            <form onSubmit={handleSaveDoctor} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Doctor Full Name *</label>
                <input
                  type="text"
                  required
                  value={docName}
                  onChange={(e) => setDocName(e.target.value)}
                  placeholder="e.g. Dr. Adebayo Okonkwo"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Clinical Title *</label>
                  <input
                    type="text"
                    required
                    value={docTitle}
                    onChange={(e) => setDocTitle(e.target.value)}
                    placeholder="e.g. Consultant Physician"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Department</label>
                  <input
                    type="text"
                    value={docDepartment}
                    onChange={(e) => setDocDepartment(e.target.value)}
                    placeholder="e.g. Internal Medicine"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Qualifications</label>
                  <input
                    type="text"
                    value={docQualifications}
                    onChange={(e) => setDocQualifications(e.target.value)}
                    placeholder="e.g. MBBS, FWACP, MSc"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Years Experience</label>
                  <input
                    type="number"
                    min={1}
                    value={docExperience}
                    onChange={(e) => setDocExperience(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Specializations (comma separated)</label>
                <input
                  type="text"
                  value={docSpecializations}
                  onChange={(e) => setDocSpecializations(e.target.value)}
                  placeholder="Cardiovascular Health, Preventive Medicine"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Photograph URL or Asset Path</label>
                <input
                  type="text"
                  value={docPhotoUrl}
                  onChange={(e) => setDocPhotoUrl(e.target.value)}
                  placeholder="/src/assets/images/... or https://..."
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Doctor Biography</label>
                <textarea
                  rows={3}
                  value={docBio}
                  onChange={(e) => setDocBio(e.target.value)}
                  placeholder="Summary of medical expertise and patient care commitment..."
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600 resize-none"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="availCheck"
                  checked={docAvailable}
                  onChange={(e) => setDocAvailable(e.target.checked)}
                  className="rounded text-teal-600"
                />
                <label htmlFor="availCheck" className="text-xs text-slate-700 font-medium">
                  Currently active and accepting new appointments
                </label>
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setDoctorModalOpen(false)}
                  className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg"
                >
                  Save Doctor Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Service Create / Edit Modal */}
      {serviceModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto text-left">
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              {editingService ? 'Edit Healthcare Service' : 'Add Healthcare Service'}
            </h3>
            <p className="text-xs text-slate-500 mb-5">
              Configure department specifications and fees.
            </p>

            <form onSubmit={handleSaveService} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Service Name *</label>
                <input
                  type="text"
                  required
                  value={srvName}
                  onChange={(e) => setSrvName(e.target.value)}
                  placeholder="e.g. Ophthalmology & Eye Care"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <input
                    type="text"
                    value={srvCategory}
                    onChange={(e) => setSrvCategory(e.target.value)}
                    placeholder="Specialist Care"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Consultation Fee</label>
                  <input
                    type="text"
                    value={srvFee}
                    onChange={(e) => setSrvFee(e.target.value)}
                    placeholder="₦20,000 / $30"
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Short Description *</label>
                <textarea
                  rows={2}
                  required
                  value={srvShortDesc}
                  onChange={(e) => setSrvShortDesc(e.target.value)}
                  placeholder="Brief overview shown on cards..."
                  className="w-full p-2.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Key Features (comma separated)</label>
                <input
                  type="text"
                  value={srvFeatures}
                  onChange={(e) => setSrvFeatures(e.target.value)}
                  placeholder="Digital retinal scan, Visual acuity testing, Glaucoma screening"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="srvActiveCheck"
                  checked={srvActive}
                  onChange={(e) => setSrvActive(e.target.checked)}
                  className="rounded text-teal-600"
                />
                <label htmlFor="srvActiveCheck" className="text-xs text-slate-700 font-medium">
                  Service is active and visible on website
                </label>
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setServiceModalOpen(false)}
                  className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg"
                >
                  Save Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
