import React from 'react';
import { useApp } from '../context/AppContext';
import { MessageSquare } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const { siteContent } = useApp();

  const cleanNumber = siteContent.whatsappNumber.replace(/^0+/, '');
  const whatsappUrl = `https://wa.me/234${cleanNumber}?text=${encodeURIComponent(
    'Hello Medicare Plus, I am visiting your healthcare platform and would like to ask a question regarding your medical services.'
  )}`;

  return (
    <aside aria-label="WhatsApp quick chat" className="fixed bottom-6 right-6 z-50">
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="w-14 h-14 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center shadow-lg transition-colors focus:outline-none focus:ring-4 focus:ring-emerald-500/30"
        aria-label={`Chat with Medicare Plus on WhatsApp (${siteContent.whatsappNumber})`}
        title={`Chat on WhatsApp (${siteContent.whatsappNumber})`}
      >
        <MessageSquare className="w-7 h-7 text-white fill-white/20" />
        
        {/* Solid calm status badge (no pulsing/shaking ping animation) */}
        <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-emerald-300 border-2 border-white rounded-full" />
      </a>
    </aside>
  );
};
