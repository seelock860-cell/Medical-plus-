import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Shield, FileText, Phone, MessageSquare, AlertCircle, X } from 'lucide-react';

export const Footer: React.FC = () => {
  const { siteContent, setActiveView } = useApp();
  const [privacyModalOpen, setPrivacyModalOpen] = useState(false);
  const [emergencyModalOpen, setEmergencyModalOpen] = useState(false);

  const scrollTo = (id: string) => {
    setActiveView('public');
    setTimeout(() => {
      const el = document.getElementById(id);
      el?.scrollIntoView({ behavior: 'smooth' });
    }, 50);
  };

  return (
    <>
      <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 text-left pt-16 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800">
            
            {/* Col 1: Brand & Bio (4 cols) */}
            <div className="lg:col-span-4 space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-500 flex items-center justify-center text-slate-900">
                  <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M10 4a2 2 0 0 1 4 0v6h6a2 2 0 1 1 0 4h-6v6a2 2 0 1 1-4 0v-6H4a2 2 0 1 1 0-4h6V4z" />
                  </svg>
                </div>
                <div>
                  <span className="text-xl font-bold tracking-tight text-white">
                    MEDICARE <span className="text-teal-400">PLUS</span>
                  </span>
                  <p className="text-[10px] text-slate-400 font-medium tracking-wide">
                    HEALTHCARE & HOSPITAL PLATFORM
                  </p>
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                Dedicated to providing patient-centered clinical care, specialized consultations, and rapid diagnostic laboratory investigations with utmost integrity.
              </p>

              <div className="pt-2 text-xs text-slate-400 space-y-1">
                <p className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                  <span>Hospital Desk: {siteContent.phone}</span>
                </p>
                <p className="flex items-center gap-2">
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>WhatsApp: {siteContent.whatsappNumber}</span>
                </p>
              </div>
            </div>

            {/* Col 2: Clinical Services (3 cols) */}
            <div className="lg:col-span-3 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Clinical Departments</h4>
              <ul className="space-y-2 text-xs text-slate-400">
                <li>
                  <button onClick={() => scrollTo('services')} className="hover:text-teal-400 transition-colors">
                    General Consultation
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollTo('services')} className="hover:text-teal-400 transition-colors">
                    Dental Care & Orthodontics
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollTo('services')} className="hover:text-teal-400 transition-colors">
                    Maternity & Antenatal Care
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollTo('services')} className="hover:text-teal-400 transition-colors">
                    Paediatrics & Child Health
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollTo('services')} className="hover:text-teal-400 transition-colors">
                    Laboratory & Diagnostics
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollTo('services')} className="hover:text-teal-400 transition-colors">
                    Specialist Consultations
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 3: Quick Navigation (2 cols) */}
            <div className="lg:col-span-2 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Patient Links</h4>
              <ul className="space-y-2 text-xs text-slate-400">
                <li>
                  <button onClick={() => scrollTo('hero')} className="hover:text-teal-400 transition-colors">
                    Hospital Overview
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollTo('doctors')} className="hover:text-teal-400 transition-colors">
                    Medical Doctors
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollTo('booking')} className="hover:text-teal-400 transition-colors">
                    Book Appointment
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollTo('why-us')} className="hover:text-teal-400 transition-colors">
                    Why Choose Us
                  </button>
                </li>
                <li>
                  <button onClick={() => scrollTo('testimonials')} className="hover:text-teal-400 transition-colors">
                    Patient Reviews
                  </button>
                </li>
                <li>
                  <button onClick={() => setPrivacyModalOpen(true)} className="hover:text-teal-400 transition-colors">
                    Privacy Notice
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 4: Hospital Policy & Emergency Disclaimer (3 cols) */}
            <div className="lg:col-span-3 space-y-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Clinical Notice</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Medicare Plus operates as an outpatient hospital and diagnostic center. We do not provide acute trauma emergency services on this web portal.
              </p>
              
              <div className="pt-2">
                <button
                  onClick={() => setEmergencyModalOpen(true)}
                  className="inline-flex items-center gap-1.5 text-xs text-amber-400 hover:text-amber-300 underline"
                >
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Read Emergency Protocol</span>
                </button>
              </div>
            </div>

          </div>

          {/* Bottom Bar: Quiet Copyright & Security */}
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <p>© {new Date().getFullYear()} MEDICARE PLUS. All rights reserved. Healthcare & Hospital Platform.</p>
            <div className="flex items-center gap-4">
              <a
                href="/medicare-plus-project.zip"
                download="medicare-plus-project.zip"
                className="text-slate-400 hover:text-teal-400 transition-colors"
                title="Download complete source code ZIP archive for GitHub and Vercel"
              >
                Download Project ZIP
              </a>
              <span>·</span>
              <button
                onClick={() => setPrivacyModalOpen(true)}
                className="hover:text-slate-400 transition-colors"
              >
                Privacy Notice & Patient Data
              </button>
              <span>·</span>
              <span className="text-teal-400 font-medium">Secured with Supabase</span>
            </div>
          </div>

        </div>
      </footer>

      {/* Privacy Notice Modal */}
      {privacyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs text-left">
          <div className="bg-white text-slate-900 rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative max-h-[85vh] overflow-y-auto">
            <button
              onClick={() => setPrivacyModalOpen(false)}
              className="absolute top-5 right-5 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Patient Privacy Notice</h3>
                <p className="text-xs text-slate-500">MEDICARE PLUS Clinical Governance</p>
              </div>
            </div>

            <div className="space-y-4 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-4">
              <p>
                At Medicare Plus, we take patient confidentiality and personal health data protection with the highest ethical and clinical seriousness.
              </p>
              
              <h4 className="font-bold text-slate-800 text-sm">1. Information We Collect</h4>
              <p>
                When you submit an appointment request, we record your legal name, contact phone number, email address, selected clinical specialty, and voluntary symptoms/notes.
              </p>

              <h4 className="font-bold text-slate-800 text-sm">2. Data Storage & Supabase Security</h4>
              <p>
                Patient appointment records are stored with Row-Level Security (RLS) policies within Supabase. Data is accessible solely to authorized clinical officers and attending physicians.
              </p>

              <h4 className="font-bold text-slate-800 text-sm">3. No Unverified Third-Party Sharing</h4>
              <p>
                We never monetize, sell, or disclose your clinical information or contact details to third-party commercial entities.
              </p>

              <h4 className="font-bold text-slate-800 text-sm">4. WhatsApp Communication</h4>
              <p>
                Appointment confirmations transmitted via WhatsApp are direct communications between you and our hospital desk at 09024971419.
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100">
              <button
                onClick={() => setPrivacyModalOpen(false)}
                className="w-full py-2.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors"
              >
                Close Notice
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Emergency Notice Modal */}
      {emergencyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs text-left">
          <div className="bg-white text-slate-900 rounded-2xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => setEmergencyModalOpen(false)}
              className="absolute top-5 right-5 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Emergency Protocol</h3>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              {siteContent.emergencyNotice}
            </p>

            <div className="mt-5 p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900">
              <p className="font-bold">Life-Threatening Emergency Numbers:</p>
              <p className="mt-1">National Emergency Services: <strong>112</strong> / <strong>767</strong></p>
              <p>Hospital Clinical Enquiries: <strong>{siteContent.phone}</strong></p>
            </div>

            <div className="mt-6">
              <button
                onClick={() => setEmergencyModalOpen(false)}
                className="w-full py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                I Understand
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
