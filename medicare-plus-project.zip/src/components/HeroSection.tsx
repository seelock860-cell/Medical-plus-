import React from 'react';
import { useApp } from '../context/AppContext';
import { HERO_IMAGE } from '../data/initialData';
import { Calendar, MessageSquare, Clock, ShieldCheck, Award, HeartPulse } from 'lucide-react';

interface HeroSectionProps {
  onBookClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onBookClick }) => {
  const { siteContent } = useApp();

  return (
    <section id="hero" className="relative bg-white pt-8 pb-16 lg:pt-14 lg:pb-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 2-Column Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Value Proposition & CTAs */}
          <div className="lg:col-span-6 space-y-6 text-left">
            
            {/* Trust Kicker: Unboxed Text with Separators */}
            <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 tracking-wide uppercase">
              <span>Licensed Outpatient Hospital</span>
              <span aria-hidden="true">·</span>
              <span>Advanced Diagnostics</span>
              <span aria-hidden="true">·</span>
              <span>Fast-Track Care</span>
            </div>

            {/* Headline with text-wrap: balance */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-[1.15] text-balance">
              Exceptional Healthcare, <br />
              <span className="text-teal-600">Centered Around You</span>
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-xl">
              Welcome to <strong className="text-slate-900 font-semibold">{siteContent.hospitalName}</strong>. 
              We blend expert multi-disciplinary medical doctors, automated diagnostic facilities, and compassionate care to protect your health at every life stage.
            </p>

            {/* Primary Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                onClick={onBookClick}
                className="px-7 py-3.5 text-base font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-sm hover:shadow transition-colors flex items-center justify-center gap-2.5 cursor-pointer whitespace-nowrap"
              >
                <Calendar className="w-5 h-5 text-teal-100" />
                <span>Book Appointment</span>
              </button>

              <a
                href={`https://wa.me/234${siteContent.whatsappNumber.replace(/^0+/, '')}?text=Hello%20Medicare%20Plus,%20I%20would%20like%20to%20make%20an%20enquiry%20or%20book%20a%20doctor%20consultation.`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3.5 text-base font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors flex items-center justify-center gap-2.5 whitespace-nowrap"
              >
                <MessageSquare className="w-5 h-5 text-emerald-600" />
                <span>WhatsApp: {siteContent.whatsappNumber}</span>
              </a>
            </div>

            {/* Micro Trust Proof */}
            <div className="pt-4 border-t border-slate-100 grid grid-cols-3 gap-4 text-left">
              <div>
                <p className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">15+</p>
                <p className="text-xs text-slate-500 font-medium">Specialist Doctors</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">&lt;15m</p>
                <p className="text-xs text-slate-500 font-medium">Average Wait Time</p>
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-bold text-slate-900 tabular-nums">25,000+</p>
                <p className="text-xs text-slate-500 font-medium">Happy Patients</p>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Asset */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200/80 shadow-lg aspect-[16/10] bg-slate-100">
              <img
                src={HERO_IMAGE}
                alt="Medicare Plus modern hospital reception and consultation suites"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              {/* Subtle glass gradient overlay at bottom */}
              <div className="absolute inset-x-0 bottom-0 p-5 bg-gradient-to-t from-slate-950/80 via-slate-950/40 to-transparent text-white">
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <p className="font-semibold text-sm text-white">Medicare Plus Outpatient Center</p>
                    <p className="text-slate-300 text-xs">Clinical consultation suites & digital diagnostics</p>
                  </div>
                  <span className="bg-teal-600/90 text-white font-medium px-2.5 py-1 rounded-md text-[11px] backdrop-blur-sm">
                    Open Today
                  </span>
                </div>
              </div>
            </div>

            {/* Floating verification badge anchored safely inside */}
            <div className="hidden sm:flex absolute bottom-3 left-3 bg-white/95 backdrop-blur-md p-3.5 rounded-xl border border-slate-200/90 shadow-md items-center gap-3 max-w-xs">
              <div className="w-9 h-9 rounded-lg bg-teal-50 flex items-center justify-center text-teal-600 shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="text-left text-xs">
                <p className="font-bold text-slate-900">Verified Clinical Quality</p>
                <p className="text-slate-500">Certified physicians & ISO standards</p>
              </div>
            </div>
          </div>

        </div>

        {/* 4-Column Feature/KPI Strip below hero split */}
        <div className="mt-16 sm:mt-20 pt-10 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-left">
          <div className="p-5 rounded-xl bg-slate-50/70 border border-slate-200/60 flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center text-slate-900 shrink-0">
              <HeartPulse className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Comprehensive Care</h2>
              <p className="text-xs text-slate-600 mt-1">From general checks to specialized surgery and maternity support.</p>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-slate-50/70 border border-slate-200/60 flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-teal-100 flex items-center justify-center text-teal-700 shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Senior Specialists</h2>
              <p className="text-xs text-slate-600 mt-1">Consult with board-certified consultants and senior medical fellows.</p>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-slate-50/70 border border-slate-200/60 flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center text-emerald-700 shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Same-Day Booking</h2>
              <p className="text-xs text-slate-600 mt-1">Online appointment scheduling with zero waiting queue delays.</p>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-slate-50/70 border border-slate-200/60 flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-700 shrink-0">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Direct WhatsApp Help</h2>
              <p className="text-xs text-slate-600 mt-1">Instant patient confirmation and inquiry assistance at 09024971419.</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
