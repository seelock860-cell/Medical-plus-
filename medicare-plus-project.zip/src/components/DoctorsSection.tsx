import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Doctor } from '../types';
import { Calendar, Award, GraduationCap, CheckCircle2 } from 'lucide-react';

interface DoctorsSectionProps {
  onSelectDoctorToBook: (doctor: Doctor) => void;
}

export const DoctorsSection: React.FC<DoctorsSectionProps> = ({ onSelectDoctorToBook }) => {
  const { doctors } = useApp();
  const [activeDepartment, setActiveDepartment] = useState<string>('All');

  const departments = ['All', ...Array.from(new Set(doctors.map((d) => d.department.split('&')[0].trim())))];

  const filteredDoctors = activeDepartment === 'All'
    ? doctors
    : doctors.filter((d) => d.department.toLowerCase().includes(activeDepartment.toLowerCase()));

  return (
    <section id="doctors" className="py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider mb-2">
            <GraduationCap className="w-4 h-4 text-teal-600" />
            <span>Clinical Leadership</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
            Meet Our Doctors & Specialists
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Our medical staff comprises experienced medical consultants, fellows of certified surgical colleges, and compassionate general practitioners.
          </p>

          {/* Department Filter Bar */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-2">
            {departments.map((dept) => (
              <button
                key={dept}
                onClick={() => setActiveDepartment(dept)}
                className={`px-4 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  activeDepartment === dept
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
                }`}
              >
                {dept}
              </button>
            ))}
          </div>
        </div>

        {/* Doctors Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredDoctors.map((doctor) => (
            <div
              key={doctor.id}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between text-left group"
            >
              <div>
                {/* Doctor Photo Frame */}
                <div className="relative aspect-square bg-slate-100 overflow-hidden">
                  <img
                    src={doctor.photoUrl}
                    alt={doctor.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      // Fallback if URL fails
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                  {doctor.isAvailable ? (
                    <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-xs text-teal-800 text-[11px] font-semibold px-2 py-0.5 rounded-md border border-teal-100 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
                      <span>Available</span>
                    </div>
                  ) : (
                    <div className="absolute top-3 right-3 bg-slate-100 text-slate-500 text-[11px] font-medium px-2 py-0.5 rounded-md">
                      Off-duty
                    </div>
                  )}
                </div>

                {/* Doctor Bio Details */}
                <div className="p-5">
                  <div className="text-xs font-medium text-teal-700 mb-1">
                    {doctor.department}
                  </div>
                  
                  <h3 className="text-base font-bold text-slate-900 leading-snug">
                    {doctor.name}
                  </h3>

                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    {doctor.title}
                  </p>

                  <div className="mt-3 text-xs text-slate-600 line-clamp-2">
                    {doctor.bio}
                  </div>

                  {/* Qualifications & Experience */}
                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5">
                    <div className="flex items-center gap-1.5 text-xs text-slate-700">
                      <GraduationCap className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-medium truncate">{doctor.qualifications}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-slate-700">
                      <Award className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{doctor.experienceYears} Years Clinical Experience</span>
                    </div>
                  </div>

                  {/* Specializations List */}
                  <div className="mt-3 flex flex-wrap gap-1">
                    {doctor.specializations.map((spec, i) => (
                      <span
                        key={i}
                        className="text-[11px] text-slate-600 bg-slate-100 px-2 py-0.5 rounded"
                      >
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="p-5 pt-0">
                <button
                  onClick={() => onSelectDoctorToBook(doctor)}
                  className="w-full py-2.5 px-3 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Book Consultation</span>
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
