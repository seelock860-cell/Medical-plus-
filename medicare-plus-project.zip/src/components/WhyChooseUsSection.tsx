import React from 'react';
import { DIAGNOSTICS_IMAGE } from '../data/initialData';
import { ShieldCheck, Clock, Award, Microscope, HeartHandshake, FileText } from 'lucide-react';

export const WhyChooseUsSection: React.FC = () => {
  return (
    <section id="why-us" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Diagnostics Lab Photo */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-xl aspect-[4/3] bg-slate-100">
              <img
                src={DIAGNOSTICS_IMAGE}
                alt="Medicare Plus Clinical Diagnostic and Pathology Laboratory"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-x-0 bottom-0 p-5 bg-gradient-to-t from-slate-950/80 via-slate-950/40 to-transparent text-white">
                <p className="font-bold text-sm text-white">Central Automated Diagnostics</p>
                <p className="text-xs text-slate-300">Automated hematology, microbiology & clinical chemistry</p>
              </div>
            </div>

            {/* Inset Metric Card */}
            <div className="hidden sm:block absolute top-4 right-4 bg-slate-900/90 backdrop-blur-md text-white p-3.5 rounded-xl shadow-lg border border-slate-700/80 text-left max-w-[200px]">
              <span className="text-xl font-bold tabular-nums text-teal-400">99.4%</span>
              <p className="text-[11px] text-slate-300 mt-0.5">Laboratory Diagnostic Accuracy Rate</p>
            </div>
          </div>

          {/* Right Column: Key Advantages */}
          <div className="lg:col-span-6 space-y-6 text-left">
            <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider">
              <Award className="w-4 h-4 text-teal-600" />
              <span>Hospital Distinction</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
              Why Patients Entrust Their Families to Medicare Plus
            </h2>

            <p className="text-base text-slate-600 leading-relaxed">
              We eliminate the friction commonly experienced in outpatient healthcare. Through digitized scheduling, rapid laboratory turnaround, and certified doctors, your clinical visit is both efficient and thorough.
            </p>

            <div className="space-y-4 pt-2">
              
              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-teal-50 flex items-center justify-center text-teal-600 shrink-0 mt-0.5">
                  <Microscope className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Modern Diagnostic Laboratory</h3>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Same-day blood work, ultrasound scans, and pathology evaluations processed directly on-site.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-blue-50 flex items-center justify-center text-slate-900 shrink-0 mt-0.5">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Strict Appointment Honesty</h3>
                  <p className="text-xs text-slate-600 mt-0.5">
                    We cap bookings per hour to prevent overcrowded waiting halls and ensure doctors dedicate adequate consultation time.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600 shrink-0 mt-0.5">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Uncompromising Patient Confidentiality</h3>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Digital medical records secured behind end-to-end access policies, strictly available to your attending physician.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 rounded-lg bg-purple-50 flex items-center justify-center text-purple-700 shrink-0 mt-0.5">
                  <HeartHandshake className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Continuous WhatsApp Clinical Follow-Up</h3>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Patients receive post-consultation prescription reminders and can query nursing officers directly on WhatsApp.
                  </p>
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
