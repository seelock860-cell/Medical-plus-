import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MedicalService } from '../types';
import {
  Stethoscope,
  Smile,
  HeartPulse,
  Baby,
  FlaskConical,
  Users,
  GraduationCap,
  Activity,
  CheckCircle2,
  Clock,
  ArrowRight,
  Info,
  X
} from 'lucide-react';

interface ServicesSectionProps {
  onSelectServiceToBook: (service: MedicalService) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectServiceToBook }) => {
  const { services } = useApp();
  const [selectedServiceForModal, setSelectedServiceForModal] = useState<MedicalService | null>(null);

  // Dynamic icon helper
  const renderIcon = (iconName: string) => {
    const props = { className: 'w-6 h-6' };
    switch (iconName.toLowerCase()) {
      case 'stethoscope':
        return <Stethoscope {...props} />;
      case 'smile':
        return <Smile {...props} />;
      case 'heartpulse':
        return <HeartPulse {...props} />;
      case 'baby':
        return <Baby {...props} />;
      case 'flaskconical':
        return <FlaskConical {...props} />;
      case 'users':
        return <Users {...props} />;
      case 'graduationcap':
        return <GraduationCap {...props} />;
      default:
        return <Activity {...props} />;
    }
  };

  const activeServices = services.filter((s) => s.isActive);

  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div className="max-w-2xl text-left">
            <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider mb-2">
              <span>Clinical Specialties</span>
              <span aria-hidden="true">·</span>
              <span>Evidence-Based Medicine</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
              Our Healthcare Services
            </h2>
            <p className="mt-3 text-base text-slate-600">
              Explore our seven primary medical departments. From preventive checkups to specialised therapies and prenatal care, Medicare Plus is equipped to support your family.
            </p>
          </div>

          <div className="text-left md:text-right shrink-0">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
              {activeServices.length} Active Departments Available
            </span>
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {activeServices.map((service, index) => (
            <div
              key={service.id}
              className={`bg-white rounded-2xl border border-slate-200/90 p-7 shadow-sm hover:shadow-md hover:border-teal-500/40 transition-all flex flex-col justify-between text-left group ${
                index === 0 ? 'lg:col-span-2 bg-gradient-to-br from-white to-teal-50/20' : ''
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-5">
                  <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 group-hover:bg-teal-600 group-hover:text-white transition-colors flex items-center justify-center">
                    {renderIcon(service.iconName)}
                  </div>
                  <span className="text-xs font-semibold text-slate-500">
                    {service.category}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-slate-900 group-hover:text-teal-700 transition-colors">
                  {service.name}
                </h3>

                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  {service.shortDescription}
                </p>

                {/* Features Pill-free List */}
                <div className="mt-5 pt-4 border-t border-slate-100 space-y-2">
                  {service.features.slice(0, 3).map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-slate-700">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-7 pt-4 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-400 font-medium block">Consultation Fee</span>
                  <span className="text-sm font-bold text-slate-900 tabular-nums">
                    {service.consultationFee}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedServiceForModal(service)}
                    className="p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
                    title="View service details"
                    aria-label={`View details for ${service.name}`}
                  >
                    <Info className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onSelectServiceToBook(service)}
                    className="px-3.5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
                  >
                    <span>Book Service</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Service Details Modal */}
      {selectedServiceForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative animate-in fade-in zoom-in-95 duration-150">
            <button
              onClick={() => setSelectedServiceForModal(null)}
              className="absolute top-5 right-5 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                {renderIcon(selectedServiceForModal.iconName)}
              </div>
              <div className="text-left">
                <span className="text-xs font-semibold text-teal-700 uppercase">{selectedServiceForModal.category}</span>
                <h3 className="text-xl font-bold text-slate-900">{selectedServiceForModal.name}</h3>
              </div>
            </div>

            <p className="text-sm text-slate-600 leading-relaxed text-left">
              {selectedServiceForModal.fullDescription || selectedServiceForModal.shortDescription}
            </p>

            <div className="mt-5 space-y-2 text-left bg-slate-50 p-4 rounded-xl border border-slate-100">
              <h4 className="text-xs font-bold uppercase text-slate-500 tracking-wide">Included in this service:</h4>
              <ul className="space-y-1.5 text-xs text-slate-700">
                {selectedServiceForModal.features.map((feat, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-5 flex items-center justify-between text-left text-xs text-slate-600">
              <div className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-slate-400" />
                <span>Duration: ~{selectedServiceForModal.durationMinutes} mins</span>
              </div>
              <span className="font-bold text-slate-900 text-sm">{selectedServiceForModal.consultationFee}</span>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setSelectedServiceForModal(null)}
                className="flex-1 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
              >
                Close
              </button>
              <button
                onClick={() => {
                  const s = selectedServiceForModal;
                  setSelectedServiceForModal(null);
                  onSelectServiceToBook(s);
                }}
                className="flex-1 py-2.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <span>Book Appointment</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
