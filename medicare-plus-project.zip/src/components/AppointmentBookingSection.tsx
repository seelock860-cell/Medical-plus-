import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Appointment, Doctor, MedicalService } from '../types';
import {
  Calendar,
  Clock,
  User,
  Phone,
  Mail,
  FileText,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  ShieldCheck,
  X,
  Copy
} from 'lucide-react';

interface BookingSectionProps {
  preselectedService?: MedicalService | null;
  preselectedDoctor?: Doctor | null;
  onClearPreselections?: () => void;
}

export const AppointmentBookingSection: React.FC<BookingSectionProps> = ({
  preselectedService,
  preselectedDoctor,
  onClearPreselections
}) => {
  const { services, doctors, siteContent, bookAppointment, showToast } = useApp();

  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [serviceId, setServiceId] = useState('');
  const [doctorId, setDoctorId] = useState('');
  const [appointmentDate, setAppointmentDate] = useState('');
  const [timeSlot, setTimeSlot] = useState('10:00 AM - 10:30 AM');
  const [notes, setNotes] = useState('');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [confirmedAppointment, setConfirmedAppointment] = useState<Appointment | null>(null);
  const [copiedRef, setCopiedRef] = useState(false);

  // Sync pre-selections if passed
  useEffect(() => {
    if (preselectedService) {
      setServiceId(preselectedService.id);
    }
    if (preselectedDoctor) {
      setDoctorId(preselectedDoctor.id);
    }
  }, [preselectedService, preselectedDoctor]);

  // Set default minimum date to today
  const today = new Date().toISOString().split('T')[0];

  const timeSlots = [
    '08:30 AM - 09:00 AM',
    '09:15 AM - 09:45 AM',
    '10:00 AM - 10:30 AM',
    '11:00 AM - 11:30 AM',
    '12:15 PM - 12:45 PM',
    '02:00 PM - 02:30 PM',
    '03:15 PM - 03:45 PM',
    '04:30 PM - 05:00 PM',
    '05:30 PM - 06:00 PM'
  ];

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!fullName.trim() || fullName.trim().length < 3) {
      newErrors.fullName = 'Please enter your full legal name (minimum 3 characters)';
    }

    const phoneClean = phoneNumber.trim().replace(/[\s-]/g, '');
    if (!phoneClean || phoneClean.length < 9) {
      newErrors.phoneNumber = 'Please enter a valid phone number (e.g. 080... or 090...)';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailAddress.trim() || !emailRegex.test(emailAddress.trim())) {
      newErrors.emailAddress = 'Please enter a valid email address';
    }

    if (!serviceId) {
      newErrors.serviceId = 'Please select a healthcare service department';
    }

    if (!appointmentDate) {
      newErrors.appointmentDate = 'Please select your preferred appointment date';
    } else if (appointmentDate < today) {
      newErrors.appointmentDate = 'Appointment date cannot be in the past';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      showToast('Please correct the highlighted form fields.', 'error');
      return;
    }

    setIsSubmitting(true);
    const selectedService = services.find((s) => s.id === serviceId);
    const selectedDoctor = doctors.find((d) => d.id === doctorId);

    const result = await bookAppointment({
      patientName: fullName.trim(),
      patientPhone: phoneNumber.trim(),
      patientEmail: emailAddress.trim().toLowerCase(),
      serviceId,
      serviceName: selectedService ? selectedService.name : 'General Consultation',
      doctorId: doctorId || undefined,
      doctorName: selectedDoctor ? selectedDoctor.name : undefined,
      appointmentDate,
      timeSlot,
      notes: notes.trim()
    });

    setIsSubmitting(false);

    if (result.success && result.appointment) {
      setConfirmedAppointment(result.appointment);
      // Reset form
      setFullName('');
      setPhoneNumber('');
      setEmailAddress('');
      setNotes('');
      if (onClearPreselections) onClearPreselections();
    } else {
      showToast(result.error || 'Failed to submit appointment request.', 'error');
    }
  };

  const copyReferenceCode = () => {
    if (confirmedAppointment?.referenceCode) {
      navigator.clipboard.writeText(confirmedAppointment.referenceCode);
      setCopiedRef(true);
      setTimeout(() => setCopiedRef(false), 2000);
    }
  };

  return (
    <section id="booking" className="py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider mb-2">
            <Calendar className="w-4 h-4 text-teal-600" />
            <span>Online Scheduling</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
            Book Your Clinical Appointment
          </h2>
          <p className="mt-3 text-base text-slate-600 leading-relaxed">
            Fill in your patient details and preferred consultation slot. Requests are logged instantly and our triage team will confirm your slot.
          </p>
        </div>

        {/* Booking Card */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-6 sm:p-10 text-left">
          
          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Row 1: Patient Name & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Full Legal Name <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => {
                      setFullName(e.target.value);
                      if (errors.fullName) setErrors({ ...errors, fullName: '' });
                    }}
                    placeholder="e.g. Adebisi Folashade"
                    className={`w-full pl-10 pr-4 py-2.5 bg-white border rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition-all ${
                      errors.fullName ? 'border-rose-400 focus:border-rose-500' : 'border-slate-300 focus:border-teal-600'
                    }`}
                  />
                </div>
                {errors.fullName && (
                  <p className="mt-1 text-xs text-rose-500 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.fullName}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Phone Number (WhatsApp Preferred) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Phone className="w-4 h-4" />
                  </div>
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => {
                      setPhoneNumber(e.target.value);
                      if (errors.phoneNumber) setErrors({ ...errors, phoneNumber: '' });
                    }}
                    placeholder="e.g. 09024971419 or 080..."
                    className={`w-full pl-10 pr-4 py-2.5 bg-white border rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition-all ${
                      errors.phoneNumber ? 'border-rose-400 focus:border-rose-500' : 'border-slate-300 focus:border-teal-600'
                    }`}
                  />
                </div>
                {errors.phoneNumber && (
                  <p className="mt-1 text-xs text-rose-500 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.phoneNumber}</span>
                  </p>
                )}
              </div>

            </div>

            {/* Row 2: Email & Service */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Email Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    value={emailAddress}
                    onChange={(e) => {
                      setEmailAddress(e.target.value);
                      if (errors.emailAddress) setErrors({ ...errors, emailAddress: '' });
                    }}
                    placeholder="e.g. patient@gmail.com"
                    className={`w-full pl-10 pr-4 py-2.5 bg-white border rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition-all ${
                      errors.emailAddress ? 'border-rose-400 focus:border-rose-500' : 'border-slate-300 focus:border-teal-600'
                    }`}
                  />
                </div>
                {errors.emailAddress && (
                  <p className="mt-1 text-xs text-rose-500 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.emailAddress}</span>
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Select Healthcare Service <span className="text-rose-500">*</span>
                </label>
                <select
                  value={serviceId}
                  onChange={(e) => {
                    setServiceId(e.target.value);
                    if (errors.serviceId) setErrors({ ...errors, serviceId: '' });
                  }}
                  className={`w-full px-3.5 py-2.5 bg-white border rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition-all ${
                    errors.serviceId ? 'border-rose-400 focus:border-rose-500' : 'border-slate-300 focus:border-teal-600'
                  }`}
                >
                  <option value="">-- Choose a Medical Department --</option>
                  {services
                    .filter((s) => s.isActive)
                    .map((srv) => (
                      <option key={srv.id} value={srv.id}>
                        {srv.name} ({srv.consultationFee})
                      </option>
                    ))}
                </select>
                {errors.serviceId && (
                  <p className="mt-1 text-xs text-rose-500 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.serviceId}</span>
                  </p>
                )}
              </div>

            </div>

            {/* Row 3: Preferred Doctor & Appointment Date */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Preferred Doctor / Specialist <span className="text-slate-400 font-normal">(Optional)</span>
                </label>
                <select
                  value={doctorId}
                  onChange={(e) => setDoctorId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition-all"
                >
                  <option value="">Any Available Specialist Doctor</option>
                  {doctors
                    .filter((d) => d.isAvailable)
                    .map((doc) => (
                      <option key={doc.id} value={doc.id}>
                        {doc.name} - {doc.role}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Preferred Consultation Date <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <input
                    type="date"
                    min={today}
                    value={appointmentDate}
                    onChange={(e) => {
                      setAppointmentDate(e.target.value);
                      if (errors.appointmentDate) setErrors({ ...errors, appointmentDate: '' });
                    }}
                    className={`w-full pl-10 pr-4 py-2.5 bg-white border rounded-lg text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500/20 transition-all ${
                      errors.appointmentDate ? 'border-rose-400 focus:border-rose-500' : 'border-slate-300 focus:border-teal-600'
                    }`}
                  />
                </div>
                {errors.appointmentDate && (
                  <p className="mt-1 text-xs text-rose-500 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{errors.appointmentDate}</span>
                  </p>
                )}
              </div>

            </div>

            {/* Row 4: Time Slot Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Preferred Consultation Time Slot
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {timeSlots.map((slot) => (
                  <button
                    type="button"
                    key={slot}
                    onClick={() => setTimeSlot(slot)}
                    className={`py-2 px-3 text-xs font-medium rounded-lg border transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                      timeSlot === slot
                        ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <Clock className="w-3 h-3 text-teal-400" />
                    <span className="tabular-nums">{slot}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Row 5: Symptoms or Clinical Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Brief Symptoms or Medical Reason <span className="text-slate-400 font-normal">(Optional & Confidential)</span>
              </label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Describe what you are experiencing or any specific concerns for your doctor..."
                className="w-full p-3.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 transition-all resize-none"
              />
            </div>

            {/* Privacy & Non-emergency Acknowledgement */}
            <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200/80 text-xs text-slate-500 space-y-1">
              <div className="flex items-center gap-1.5 font-medium text-slate-700">
                <ShieldCheck className="w-4 h-4 text-teal-600" />
                <span>Patient Privacy & Scheduling Policy</span>
              </div>
              <p>
                By booking, your details will be recorded in our secure Supabase clinical register. Medicare Plus provides planned outpatient care. If you have an acute life-threatening emergency, please visit the emergency hospital room immediately.
              </p>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-6 text-sm font-bold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 rounded-lg shadow-sm hover:shadow transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Recording Appointment in Supabase...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Submit Appointment Request</span>
                  </>
                )}
              </button>
            </div>

          </form>

        </div>

      </div>

      {/* Confirmation Modal */}
      {confirmedAppointment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative animate-in fade-in zoom-in-95 duration-150 text-left">
            
            <button
              onClick={() => setConfirmedAppointment(null)}
              className="absolute top-5 right-5 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-14 h-14 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mb-4">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="text-2xl font-bold text-slate-900 tracking-tight">
              Appointment Request Submitted!
            </h3>

            <p className="mt-1 text-sm text-slate-600">
              Thank you, <strong className="text-slate-900">{confirmedAppointment.patientName}</strong>. Your clinical request has been securely recorded.
            </p>

            {/* Reference Box */}
            <div className="mt-5 p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-500 font-semibold uppercase block">Appointment Reference Code</span>
                <span className="text-xl font-extrabold text-teal-700 font-mono tracking-wider tabular-nums">
                  {confirmedAppointment.referenceCode}
                </span>
              </div>
              <button
                onClick={copyReferenceCode}
                className="p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-200 transition-colors flex items-center gap-1 text-xs font-medium"
              >
                <Copy className="w-4 h-4" />
                <span>{copiedRef ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>

            {/* Details Summary */}
            <div className="mt-4 space-y-2 text-xs text-slate-600 border-t border-slate-100 pt-3">
              <div className="flex justify-between">
                <span className="text-slate-500">Service:</span>
                <span className="font-semibold text-slate-800">{confirmedAppointment.serviceName}</span>
              </div>
              {confirmedAppointment.doctorName && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Doctor:</span>
                  <span className="font-semibold text-slate-800">{confirmedAppointment.doctorName}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-slate-500">Date:</span>
                <span className="font-semibold text-slate-800">{confirmedAppointment.appointmentDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Time Slot:</span>
                <span className="font-semibold text-slate-800">{confirmedAppointment.timeSlot}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Status:</span>
                <span className="font-semibold text-amber-600 uppercase">Pending Staff Review</span>
              </div>
            </div>

            {/* Direct WhatsApp Confirmation Button */}
            <div className="mt-6 space-y-2.5">
              <a
                href={`https://wa.me/234${siteContent.whatsappNumber.replace(/^0+/, '')}?text=${encodeURIComponent(
                  `Hello Medicare Plus, I just submitted an appointment request.\nReference: ${confirmedAppointment.referenceCode}\nPatient: ${confirmedAppointment.patientName}\nService: ${confirmedAppointment.serviceName}\nDate: ${confirmedAppointment.appointmentDate} (${confirmedAppointment.timeSlot})\nKindly confirm my consultation slot.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Confirm Instantly via WhatsApp ({siteContent.whatsappNumber})</span>
              </a>

              <button
                onClick={() => setConfirmedAppointment(null)}
                className="w-full py-2.5 px-4 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors text-center"
              >
                Close & Return
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
