import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Phone, MessageSquare, MapPin, Clock, Mail, Send, AlertTriangle, CheckCircle2 } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { siteContent, showToast } = useApp();

  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [message, setMessage] = useState('');
  const [isSent, setIsSent] = useState(false);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName.trim() || !contactEmail.trim() || !message.trim()) {
      showToast('Please complete name, email, and message fields.', 'error');
      return;
    }

    setIsSent(true);
    showToast('Inquiry message received! Our team will respond shortly.', 'success');
    setContactName('');
    setContactEmail('');
    setContactPhone('');
    setMessage('');
    setTimeout(() => setIsSent(false), 5000);
  };

  return (
    <section id="contact" className="py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-700 uppercase tracking-wider mb-2">
            <MapPin className="w-4 h-4 text-teal-600" />
            <span>Hospital Contact & Access</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight text-balance">
            Get in Touch with Medicare Plus
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Have questions about specialized consultations, laboratory investigations, or appointment scheduling? We are here to assist you.
          </p>
        </div>

        {/* Emergency Notice Card */}
        <div className="mb-12 bg-amber-50 border border-amber-200 rounded-xl p-4 sm:p-5 text-left flex items-start gap-3.5">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="text-xs sm:text-sm text-amber-900 leading-relaxed">
            <strong className="font-semibold block mb-0.5">Important Emergency Notice:</strong>
            {siteContent.emergencyNotice}
          </div>
        </div>

        {/* 2-Column Contact Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Left Column: Contact Cards */}
          <div className="lg:col-span-5 space-y-6 text-left">
            
            {/* WhatsApp Highlight Box */}
            <div className="bg-gradient-to-br from-teal-700 to-slate-900 text-white rounded-2xl p-6 sm:p-7 shadow-md">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-teal-300">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-xs text-teal-200 font-semibold uppercase tracking-wider">Fast Support</span>
                  <h3 className="text-lg font-bold text-white">Direct WhatsApp Hotline</h3>
                </div>
              </div>
              <p className="text-xs text-slate-200 leading-relaxed mb-5">
                Chat with our front-desk triage and clinical coordination desk for quick replies, appointment confirmations, and inquiries.
              </p>
              <a
                href={`https://wa.me/234${siteContent.whatsappNumber.replace(/^0+/, '')}?text=Hello%20Medicare%20Plus,%20I%20would%20like%20to%20make%20an%20enquiry.`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 text-xs font-bold text-slate-900 bg-teal-400 hover:bg-teal-300 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Message on WhatsApp ({siteContent.whatsappNumber})</span>
              </a>
            </div>

            {/* Hospital Details List */}
            <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4 text-left">
              
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase">Hospital Location</h4>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{siteContent.address}</p>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-3 flex items-start gap-3">
                <Phone className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase">Telephone Desk</h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    <a href={`tel:${siteContent.phone}`} className="hover:text-teal-600 font-medium">
                      {siteContent.phone}
                    </a>
                  </p>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-3 flex items-start gap-3">
                <Mail className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase">Official Email</h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    <a href={`mailto:${siteContent.email}`} className="hover:text-teal-600 font-medium">
                      {siteContent.email}
                    </a>
                  </p>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-3 flex items-start gap-3">
                <Clock className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900 uppercase">Consultation Hours</h4>
                  <p className="text-xs text-slate-600 mt-0.5">{siteContent.workingHours}</p>
                </div>
              </div>

            </div>

          </div>

          {/* Right Column: Contact Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 text-left">
              <h3 className="text-xl font-bold text-slate-900 mb-1">Send a Message</h3>
              <p className="text-xs text-slate-500 mb-6">
                Submit an inquiry and our client care officer will reply via email or phone within 2 hours during clinic hours.
              </p>

              {isSent ? (
                <div className="p-6 bg-teal-50 border border-teal-200 rounded-xl text-center space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-teal-600 mx-auto" />
                  <h4 className="text-base font-bold text-slate-900">Message Delivered</h4>
                  <p className="text-xs text-slate-600">
                    Thank you for reaching out. We have received your note and will contact you promptly.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Your Full Name *</label>
                      <input
                        type="text"
                        required
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        placeholder="e.g. John Okoye"
                        className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address *</label>
                      <input
                        type="email"
                        required
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                        placeholder="e.g. john@example.com"
                        className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number (Optional)</label>
                    <input
                      type="tel"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      placeholder="e.g. 080..."
                      className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Your Message or Enquiry *</label>
                    <textarea
                      rows={4}
                      required
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="How can Medicare Plus assist you today?"
                      className="w-full p-3.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 px-6 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <Send className="w-3.5 h-3.5 text-teal-400" />
                    <span>Send Message to Hospital</span>
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
