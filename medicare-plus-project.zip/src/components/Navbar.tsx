import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Phone, Menu, X, ArrowRight } from 'lucide-react';

interface NavbarProps {
  onBookClick: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onBookClick }) => {
  const { siteContent, activeView, setActiveView } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    if (activeView === 'admin') {
      setActiveView('public');
      setTimeout(() => {
        const el = document.getElementById(id);
        el?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const el = document.getElementById(id);
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Main Navigation: 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
          
          {/* Zone 1: Single text element wordmark */}
          <button
            onClick={() => scrollTo('hero')}
            className="flex items-center gap-2.5 text-left group shrink-0"
          >
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-teal-400 shadow-sm group-hover:bg-slate-800 transition-colors">
              <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                <path d="M10 4a2 2 0 0 1 4 0v6h6a2 2 0 1 1 0 4h-6v6a2 2 0 1 1-4 0v-6H4a2 2 0 1 1 0-4h6V4z" />
              </svg>
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap">
                MEDICARE <span className="text-teal-600">PLUS</span>
              </span>
              <p className="text-[11px] text-slate-500 font-medium tracking-wide">
                HEALTHCARE & HOSPITAL
              </p>
            </div>
          </button>

          {/* Zone 2: Nav Links */}
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-700">
            <button
              onClick={() => scrollTo('services')}
              className="hover:text-teal-600 transition-colors whitespace-nowrap shrink-0"
            >
              Our Services
            </button>
            <button
              onClick={() => scrollTo('doctors')}
              className="hover:text-teal-600 transition-colors whitespace-nowrap shrink-0"
            >
              Meet Doctors
            </button>
            <button
              onClick={() => scrollTo('why-us')}
              className="hover:text-teal-600 transition-colors whitespace-nowrap shrink-0"
            >
              Why Choose Us
            </button>
            <button
              onClick={() => scrollTo('testimonials')}
              className="hover:text-teal-600 transition-colors whitespace-nowrap shrink-0"
            >
              Patient Reviews
            </button>
            <button
              onClick={() => scrollTo('contact')}
              className="hover:text-teal-600 transition-colors whitespace-nowrap shrink-0"
            >
              Contact & Location
            </button>
          </nav>

          {/* Zone 3: 1 Primary CTA */}
          <div className="hidden sm:flex items-center gap-4 shrink-0">
            <a
              href={`tel:${siteContent.phone}`}
              className="hidden xl:flex items-center gap-2 text-xs font-semibold text-slate-700 hover:text-teal-600 px-3 py-2 rounded-lg border border-slate-200 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-teal-600" />
              <span>{siteContent.phone}</span>
            </a>

            <button
              onClick={onBookClick}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-sm hover:shadow transition-all whitespace-nowrap shrink-0 flex items-center gap-2 cursor-pointer"
            >
              <span>Book Appointment</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={onBookClick}
              className="sm:hidden px-3 py-1.5 text-xs font-semibold text-white bg-teal-600 rounded-lg whitespace-nowrap"
            >
              Book
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-lg">
            <button
              onClick={() => scrollTo('services')}
              className="block w-full text-left py-2 text-sm font-medium text-slate-800 hover:text-teal-600"
            >
              Healthcare Services
            </button>
            <button
              onClick={() => scrollTo('doctors')}
              className="block w-full text-left py-2 text-sm font-medium text-slate-800 hover:text-teal-600"
            >
              Medical Specialists & Doctors
            </button>
            <button
              onClick={() => scrollTo('why-us')}
              className="block w-full text-left py-2 text-sm font-medium text-slate-800 hover:text-teal-600"
            >
              Why Choose Medicare Plus
            </button>
            <button
              onClick={() => scrollTo('testimonials')}
              className="block w-full text-left py-2 text-sm font-medium text-slate-800 hover:text-teal-600"
            >
              Patient Testimonials
            </button>
            <button
              onClick={() => scrollTo('contact')}
              className="block w-full text-left py-2 text-sm font-medium text-slate-800 hover:text-teal-600"
            >
              Contact & Hospital Address
            </button>
            
            <div className="pt-3 border-t border-slate-100 flex flex-col gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onBookClick();
                }}
                className="w-full py-2.5 text-center text-sm font-semibold text-white bg-teal-600 rounded-lg shadow"
              >
                Book Appointment Now
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
