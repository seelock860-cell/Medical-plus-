import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Appointment, Doctor, MedicalService, SiteContent, SupabaseConfig } from '../types';
import {
  INITIAL_SERVICES,
  INITIAL_DOCTORS,
  INITIAL_APPOINTMENTS,
  INITIAL_SITE_CONTENT
} from '../data/initialData';

const CONFIG_KEY = 'medicare_supabase_config';
const LOCAL_SERVICES_KEY = 'medicare_services_store';
const LOCAL_DOCTORS_KEY = 'medicare_doctors_store';
const LOCAL_APPOINTMENTS_KEY = 'medicare_appointments_store';
const LOCAL_CONTENT_KEY = 'medicare_content_store';
const LOCAL_ADMIN_KEY = 'medicare_admin_session';

export const DEFAULT_SUPABASE_URL = 'https://mcnmvvqddhsxmgytcgfk.supabase.co';
export const DEFAULT_SUPABASE_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jbm12dnFkZGhzeG1neXRjZ2ZrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM1MTM3MzIsImV4cCI6MjEwOTA4OTczMn0.MwhGDpLiZWz5LJryruPYB_wot_dxZF7E7F0uKmuHNQA';

export function normalizeSupabaseUrl(url: string): string {
  if (!url) return '';
  return url.trim().replace(/\/rest\/v1\/?$/, '').replace(/\/$/, '');
}

export function getStoredSupabaseConfig(): SupabaseConfig {
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.url && parsed.anonKey) {
        return {
          url: normalizeSupabaseUrl(parsed.url),
          anonKey: parsed.anonKey.trim(),
          isConnected: true,
          lastTestedAt: parsed.lastTestedAt
        };
      }
    }
  } catch {
    // ignore parse error
  }

  // Check Vite env or fallback to user project credentials
  const envUrl = (import.meta as any).env?.VITE_SUPABASE_URL || DEFAULT_SUPABASE_URL;
  const envKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || DEFAULT_SUPABASE_ANON_KEY;

  return {
    url: normalizeSupabaseUrl(envUrl),
    anonKey: envKey.trim(),
    isConnected: Boolean(envUrl && envKey)
  };
}

export function saveStoredSupabaseConfig(url: string, anonKey: string, isConnected = false) {
  const cleanUrl = normalizeSupabaseUrl(url);
  const cleanKey = anonKey.trim();
  const config: SupabaseConfig = {
    url: cleanUrl,
    anonKey: cleanKey,
    isConnected,
    lastTestedAt: new Date().toISOString()
  };
  localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
  return config;
}

let cachedClient: SupabaseClient | null = null;
let cachedClientKey = '';

export function getSupabaseClient(): SupabaseClient | null {
  const config = getStoredSupabaseConfig();
  if (!config.url || !config.anonKey) {
    return null;
  }

  const cleanUrl = normalizeSupabaseUrl(config.url);
  const key = `${cleanUrl}_${config.anonKey}`;
  if (cachedClient && cachedClientKey === key) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(cleanUrl, config.anonKey);
    cachedClientKey = key;
    return cachedClient;
  } catch (err) {
    console.error('Error instantiating Supabase client:', err);
    return null;
  }
}

export async function testSupabaseConnection(url: string, anonKey: string): Promise<{ success: boolean; message: string }> {
  if (!url || !anonKey) {
    return { success: false, message: 'Please provide both Project URL and Publishable Anon Key.' };
  }

  const cleanUrl = normalizeSupabaseUrl(url);
  const cleanKey = anonKey.trim();

  try {
    const testClient = createClient(cleanUrl, cleanKey);
    // Query services or check auth session
    const { error } = await testClient.from('services').select('id').limit(1);

    if (error && error.code !== 'PGRST116') {
      // If table doesn't exist yet, we still know client successfully connected and authenticated to the project!
      if (
        error.code === 'PGRST205' ||
        error.code === '42P01' ||
        error.message?.includes('schema cache') ||
        error.message?.includes('does not exist')
      ) {
        return {
          success: true,
          message: 'Connected to Supabase Project (mcnmvvqddhsxmgytcgfk)! Tables are not created in your database yet. Copy the SQL script below and execute it in your Supabase SQL Editor.'
        };
      }
      return { success: false, message: error.message || 'Failed to query Supabase.' };
    }

    return { success: true, message: 'Successfully connected and verified Supabase project database!' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Network error while attempting to connect to Supabase.' };
  }
}

// ---------------------------------------------------------------------------
// LOCAL STORAGE DATA STORE UTILITIES (Seamless fallback when offline/pre-setup)
// ---------------------------------------------------------------------------

function loadFromLocal<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch {
    return fallback;
  }
}

function saveToLocal<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save to localStorage', e);
  }
}

// ---------------------------------------------------------------------------
// DATA API LAYER (Supabase First, Local Fallback)
// ---------------------------------------------------------------------------

export async function fetchServicesData(): Promise<MedicalService[]> {
  const client = getSupabaseClient();
  if (client) {
    try {
      const { data, error } = await client.from('services').select('*').order('created_at', { ascending: true });
      if (!error && data && data.length > 0) {
        return data.map((item: any) => ({
          id: item.id,
          name: item.name,
          category: item.category || 'General Care',
          shortDescription: item.short_description || '',
          fullDescription: item.full_description || '',
          iconName: item.icon_name || 'Stethoscope',
          durationMinutes: item.duration_minutes || 30,
          consultationFee: item.consultation_fee || 'Contact Clinic',
          availableDays: item.available_days || ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
          isActive: item.is_active ?? true,
          features: item.features || []
        }));
      }
    } catch (e) {
      console.warn('Supabase fetchServices fallback to local', e);
    }
  }
  return loadFromLocal<MedicalService[]>(LOCAL_SERVICES_KEY, INITIAL_SERVICES);
}

export async function saveServicesData(services: MedicalService[]): Promise<void> {
  saveToLocal(LOCAL_SERVICES_KEY, services);
}

export async function fetchDoctorsData(): Promise<Doctor[]> {
  const client = getSupabaseClient();
  if (client) {
    try {
      const { data, error } = await client.from('doctors').select('*').order('experience_years', { ascending: false });
      if (!error && data && data.length > 0) {
        return data.map((item: any) => ({
          id: item.id,
          name: item.name,
          title: item.title,
          role: item.role,
          department: item.department,
          specializations: item.specializations || [],
          qualifications: item.qualifications,
          experienceYears: item.experience_years,
          bio: item.bio,
          photoUrl: item.photo_url || '',
          availableDays: item.available_days || [],
          isAvailable: item.is_available ?? true,
          phone: item.phone,
          email: item.email
        }));
      }
    } catch (e) {
      console.warn('Supabase fetchDoctors fallback to local', e);
    }
  }
  return loadFromLocal<Doctor[]>(LOCAL_DOCTORS_KEY, INITIAL_DOCTORS);
}

export async function saveDoctorsData(doctors: Doctor[]): Promise<void> {
  saveToLocal(LOCAL_DOCTORS_KEY, doctors);
}

export async function fetchAppointmentsData(): Promise<Appointment[]> {
  const client = getSupabaseClient();
  if (client) {
    try {
      const { data, error } = await client.from('appointments').select('*').order('created_at', { ascending: false });
      if (!error && data && data.length > 0) {
        return data.map((item: any) => ({
          id: item.id,
          referenceCode: item.reference_code,
          patientName: item.patient_name,
          patientPhone: item.patient_phone,
          patientEmail: item.patient_email,
          serviceId: item.service_id || '',
          serviceName: item.service_name,
          doctorId: item.doctor_id,
          doctorName: item.doctor_name,
          appointmentDate: item.appointment_date,
          timeSlot: item.time_slot,
          notes: item.notes,
          status: item.status,
          createdAt: item.created_at,
          updatedAt: item.updated_at
        }));
      }
    } catch (e) {
      console.warn('Supabase fetchAppointments fallback to local', e);
    }
  }
  return loadFromLocal<Appointment[]>(LOCAL_APPOINTMENTS_KEY, INITIAL_APPOINTMENTS);
}

export async function saveAppointmentsData(appointments: Appointment[]): Promise<void> {
  saveToLocal(LOCAL_APPOINTMENTS_KEY, appointments);
}

export async function createAppointmentInDb(appointment: Appointment): Promise<{ success: boolean; data?: Appointment; error?: string }> {
  const client = getSupabaseClient();
  if (client) {
    try {
      const { data, error } = await client.from('appointments').insert([
        {
          reference_code: appointment.referenceCode,
          patient_name: appointment.patientName,
          patient_phone: appointment.patientPhone,
          patient_email: appointment.patientEmail,
          service_id: appointment.serviceId,
          service_name: appointment.serviceName,
          doctor_id: appointment.doctorId || null,
          doctor_name: appointment.doctorName || null,
          appointment_date: appointment.appointmentDate,
          time_slot: appointment.timeSlot,
          notes: appointment.notes || '',
          status: appointment.status
        }
      ]).select().single();

      if (error) {
        console.warn('Supabase insert appointment error, saving locally:', error.message);
      } else if (data) {
        return {
          success: true,
          data: {
            ...appointment,
            id: data.id || appointment.id
          }
        };
      }
    } catch (err: any) {
      console.warn('Failed to insert into Supabase, saving locally:', err);
    }
  }

  // Local storage save
  const current = loadFromLocal<Appointment[]>(LOCAL_APPOINTMENTS_KEY, INITIAL_APPOINTMENTS);
  const updated = [appointment, ...current];
  saveToLocal(LOCAL_APPOINTMENTS_KEY, updated);
  return { success: true, data: appointment };
}

export async function fetchSiteContentData(): Promise<SiteContent> {
  const client = getSupabaseClient();
  if (client) {
    try {
      const { data, error } = await client.from('site_content').select('data').eq('id', 'main').single();
      if (!error && data?.data) {
        return data.data as SiteContent;
      }
    } catch (e) {
      console.warn('Supabase fetchSiteContent fallback to local', e);
    }
  }
  return loadFromLocal<SiteContent>(LOCAL_CONTENT_KEY, INITIAL_SITE_CONTENT);
}

export async function saveSiteContentData(content: SiteContent): Promise<void> {
  saveToLocal(LOCAL_CONTENT_KEY, content);
  const client = getSupabaseClient();
  if (client) {
    try {
      await client.from('site_content').upsert({ id: 'main', data: content });
    } catch (e) {
      console.warn('Supabase upsert site_content error', e);
    }
  }
}

// ---------------------------------------------------------------------------
// ADMIN AUTHENTICATION
// ---------------------------------------------------------------------------

export async function authenticateAdmin(usernameOrEmail: string, password: string): Promise<{ success: boolean; user?: { id: string; username: string; email: string; role: string }; message?: string }> {
  const cleanUser = usernameOrEmail.trim().toLowerCase();
  const cleanPass = password.trim();

  // 1. Try Supabase Auth if client is configured
  const client = getSupabaseClient();
  if (client && cleanUser.includes('@')) {
    try {
      const { data, error } = await client.auth.signInWithPassword({
        email: cleanUser,
        password: cleanPass
      });
      if (!error && data.user) {
        const adminUser = {
          id: data.user.id,
          username: data.user.email?.split('@')[0] || 'admin',
          email: data.user.email || 'admin@medicareplus.com',
          role: 'Administrator'
        };
        localStorage.setItem(LOCAL_ADMIN_KEY, JSON.stringify(adminUser));
        return { success: true, user: adminUser };
      }
    } catch {
      // continue to fallback check
    }
  }

  // 2. Check for configured Admin Credentials:
  // Admin username: "morning", password: "morning234"
  if (
    (cleanUser === 'morning' || cleanUser === 'morning@medicareplus.com') &&
    cleanPass === 'morning234'
  ) {
    const adminUser = {
      id: 'admin-morning-1',
      username: 'morning',
      email: 'morning@medicareplus.com',
      role: 'Hospital Administrator'
    };
    localStorage.setItem(LOCAL_ADMIN_KEY, JSON.stringify(adminUser));
    return { success: true, user: adminUser };
  }

  return { success: false, message: 'Invalid administrator credentials. Please check your username and password.' };
}

export function getStoredAdminSession() {
  try {
    const raw = localStorage.getItem(LOCAL_ADMIN_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function clearAdminSession() {
  localStorage.removeItem(LOCAL_ADMIN_KEY);
  const client = getSupabaseClient();
  if (client) {
    client.auth.signOut().catch(() => {});
  }
}
