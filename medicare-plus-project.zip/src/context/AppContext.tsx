import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Appointment,
  AppointmentStatus,
  Doctor,
  MedicalService,
  SiteContent,
  SupabaseConfig,
  AdminUser
} from '../types';
import {
  getStoredSupabaseConfig,
  saveStoredSupabaseConfig,
  testSupabaseConnection,
  fetchServicesData,
  saveServicesData,
  fetchDoctorsData,
  saveDoctorsData,
  fetchAppointmentsData,
  saveAppointmentsData,
  createAppointmentInDb,
  fetchSiteContentData,
  saveSiteContentData,
  authenticateAdmin,
  getStoredAdminSession,
  clearAdminSession
} from '../lib/supabase';
import { INITIAL_SERVICES, INITIAL_DOCTORS, INITIAL_APPOINTMENTS, INITIAL_SITE_CONTENT } from '../data/initialData';

interface ToastNotification {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  services: MedicalService[];
  doctors: Doctor[];
  appointments: Appointment[];
  siteContent: SiteContent;
  supabaseConfig: SupabaseConfig;
  adminUser: AdminUser | null;
  isAdminLoggedIn: boolean;
  isLoading: boolean;
  activeView: 'public' | 'admin';
  toast: ToastNotification | null;
  selectedDoctorForBooking: Doctor | null;
  selectedServiceForBooking: MedicalService | null;
  
  // Navigation
  setActiveView: (view: 'public' | 'admin') => void;
  setSelectedDoctorForBooking: (doctor: Doctor | null) => void;
  setSelectedServiceForBooking: (service: MedicalService | null) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  
  // Auth
  loginAdmin: (usernameOrEmail: string, password: string) => Promise<{ success: boolean; message?: string }>;
  logoutAdmin: () => void;
  
  // Supabase
  updateSupabaseConfig: (url: string, anonKey: string) => Promise<{ success: boolean; message: string }>;
  testSupabaseConfig: (url: string, anonKey: string) => Promise<{ success: boolean; message: string }>;
  
  // Doctors CRUD
  addDoctor: (doctor: Omit<Doctor, 'id'>) => Promise<void>;
  updateDoctor: (id: string, updates: Partial<Doctor>) => Promise<void>;
  deleteDoctor: (id: string) => Promise<void>;
  
  // Services CRUD
  addService: (service: Omit<MedicalService, 'id'>) => Promise<void>;
  updateService: (id: string, updates: Partial<MedicalService>) => Promise<void>;
  deleteService: (id: string) => Promise<void>;
  
  // Appointments CRUD
  bookAppointment: (data: {
    patientName: string;
    patientPhone: string;
    patientEmail: string;
    serviceId: string;
    serviceName: string;
    doctorId?: string;
    doctorName?: string;
    appointmentDate: string;
    timeSlot: string;
    notes?: string;
  }) => Promise<{ success: boolean; appointment?: Appointment; error?: string }>;
  updateAppointmentStatus: (id: string, status: AppointmentStatus) => Promise<void>;
  deleteAppointment: (id: string) => Promise<void>;
  
  // Site Content
  updateSiteContent: (newContent: Partial<SiteContent>) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [services, setServices] = useState<MedicalService[]>(INITIAL_SERVICES);
  const [doctors, setDoctors] = useState<Doctor[]>(INITIAL_DOCTORS);
  const [appointments, setAppointments] = useState<Appointment[]>(INITIAL_APPOINTMENTS);
  const [siteContent, setSiteContent] = useState<SiteContent>(INITIAL_SITE_CONTENT);
  const [supabaseConfig, setSupabaseConfig] = useState<SupabaseConfig>(getStoredSupabaseConfig());
  const [adminUser, setAdminUser] = useState<AdminUser | null>(getStoredAdminSession());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const isHashAdmin = () => {
    const h = window.location.hash.toLowerCase();
    return h === '#/admin' || h === '#admin';
  };

  const [activeView, setActiveViewState] = useState<'public' | 'admin'>(() =>
    isHashAdmin() ? 'admin' : 'public'
  );
  const [toast, setToast] = useState<ToastNotification | null>(null);
  const [selectedDoctorForBooking, setSelectedDoctorForBooking] = useState<Doctor | null>(null);
  const [selectedServiceForBooking, setSelectedServiceForBooking] = useState<MedicalService | null>(null);

  // Sync activeView with browser URL hash #/admin
  useEffect(() => {
    const handleHashChange = () => {
      if (isHashAdmin()) {
        setActiveViewState('admin');
      } else {
        setActiveViewState('public');
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const setActiveView = (view: 'public' | 'admin') => {
    setActiveViewState(view);
    if (view === 'admin') {
      if (window.location.hash !== '#/admin') {
        window.location.hash = '/admin';
      }
    } else {
      if (isHashAdmin()) {
        history.replaceState(null, '', window.location.pathname + window.location.search);
      }
    }
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToast({ id, type, message });
    setTimeout(() => {
      setToast((curr) => (curr?.id === id ? null : curr));
    }, 4500);
  };

  // Initial load
  useEffect(() => {
    let isMounted = true;
    async function loadInitialData() {
      try {
        setIsLoading(true);
        const [loadedServices, loadedDoctors, loadedAppointments, loadedContent] = await Promise.all([
          fetchServicesData(),
          fetchDoctorsData(),
          fetchAppointmentsData(),
          fetchSiteContentData()
        ]);
        if (isMounted) {
          if (loadedServices?.length) setServices(loadedServices);
          if (loadedDoctors?.length) setDoctors(loadedDoctors);
          if (loadedAppointments?.length) setAppointments(loadedAppointments);
          if (loadedContent) setSiteContent(loadedContent);
        }
      } catch (err) {
        console.error('Error loading initial data:', err);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    }

    loadInitialData();
    return () => {
      isMounted = false;
    };
  }, []);

  // Admin Login
  const loginAdmin = async (usernameOrEmail: string, password: string) => {
    const res = await authenticateAdmin(usernameOrEmail, password);
    if (res.success && res.user) {
      setAdminUser(res.user);
      showToast(`Welcome back, ${res.user.username}! Admin access granted.`, 'success');
      return { success: true };
    }
    showToast(res.message || 'Login failed.', 'error');
    return { success: false, message: res.message };
  };

  const logoutAdmin = () => {
    clearAdminSession();
    setAdminUser(null);
    setActiveView('public');
    showToast('Admin logged out successfully.', 'info');
  };

  // Supabase management
  const testSupabaseConfig = async (url: string, anonKey: string) => {
    return await testSupabaseConnection(url, anonKey);
  };

  const updateSupabaseConfig = async (url: string, anonKey: string) => {
    const test = await testSupabaseConnection(url, anonKey);
    const updated = saveStoredSupabaseConfig(url, anonKey, test.success);
    setSupabaseConfig(updated);
    if (test.success) {
      showToast('Supabase settings saved and verified successfully!', 'success');
      // Refresh data with newly configured Supabase
      try {
        const [freshServices, freshDoctors, freshAppointments] = await Promise.all([
          fetchServicesData(),
          fetchDoctorsData(),
          fetchAppointmentsData()
        ]);
        if (freshServices.length) setServices(freshServices);
        if (freshDoctors.length) setDoctors(freshDoctors);
        if (freshAppointments.length) setAppointments(freshAppointments);
      } catch (e) {
        console.error(e);
      }
    } else {
      showToast(`Supabase config saved, but connection check returned: ${test.message}`, 'info');
    }
    return test;
  };

  // Doctor CRUD
  const addDoctor = async (doctorData: Omit<Doctor, 'id'>) => {
    const newDoc: Doctor = {
      ...doctorData,
      id: `doc-${Date.now()}`
    };
    const updated = [newDoc, ...doctors];
    setDoctors(updated);
    await saveDoctorsData(updated);
    showToast(`Doctor "${newDoc.name}" added successfully!`);
  };

  const updateDoctor = async (id: string, updates: Partial<Doctor>) => {
    const updated = doctors.map((doc) => (doc.id === id ? { ...doc, ...updates } : doc));
    setDoctors(updated);
    await saveDoctorsData(updated);
    showToast('Doctor profile updated successfully!');
  };

  const deleteDoctor = async (id: string) => {
    const target = doctors.find((d) => d.id === id);
    const updated = doctors.filter((doc) => doc.id !== id);
    setDoctors(updated);
    await saveDoctorsData(updated);
    showToast(`Doctor "${target?.name || ''}" removed.`, 'info');
  };

  // Services CRUD
  const addService = async (serviceData: Omit<MedicalService, 'id'>) => {
    const newService: MedicalService = {
      ...serviceData,
      id: `srv-${Date.now()}`
    };
    const updated = [...services, newService];
    setServices(updated);
    await saveServicesData(updated);
    showToast(`Service "${newService.name}" created successfully!`);
  };

  const updateService = async (id: string, updates: Partial<MedicalService>) => {
    const updated = services.map((s) => (s.id === id ? { ...s, ...updates } : s));
    setServices(updated);
    await saveServicesData(updated);
    showToast('Service details updated successfully!');
  };

  const deleteService = async (id: string) => {
    const target = services.find((s) => s.id === id);
    const updated = services.filter((s) => s.id !== id);
    setServices(updated);
    await saveServicesData(updated);
    showToast(`Service "${target?.name || ''}" removed.`, 'info');
  };

  // Appointments CRUD
  const bookAppointment = async (data: {
    patientName: string;
    patientPhone: string;
    patientEmail: string;
    serviceId: string;
    serviceName: string;
    doctorId?: string;
    doctorName?: string;
    appointmentDate: string;
    timeSlot: string;
    notes?: string;
  }) => {
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const referenceCode = `MCP-${randomNum}`;
    const newApt: Appointment = {
      id: `apt-${Date.now()}`,
      referenceCode,
      ...data,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    const res = await createAppointmentInDb(newApt);
    if (res.success && res.data) {
      setAppointments((curr) => [res.data!, ...curr]);
      return { success: true, appointment: res.data };
    }
    return { success: false, error: res.error || 'Failed to submit appointment' };
  };

  const updateAppointmentStatus = async (id: string, status: AppointmentStatus) => {
    const updated = appointments.map((apt) =>
      apt.id === id ? { ...apt, status, updatedAt: new Date().toISOString() } : apt
    );
    setAppointments(updated);
    await saveAppointmentsData(updated);
    showToast(`Appointment status marked as "${status.toUpperCase()}".`);
  };

  const deleteAppointment = async (id: string) => {
    const updated = appointments.filter((apt) => apt.id !== id);
    setAppointments(updated);
    await saveAppointmentsData(updated);
    showToast('Appointment record deleted.', 'info');
  };

  // Site Content
  const updateSiteContent = async (newContent: Partial<SiteContent>) => {
    const updated = { ...siteContent, ...newContent };
    setSiteContent(updated);
    await saveSiteContentData(updated);
    showToast('Website content updated successfully!');
  };

  return (
    <AppContext.Provider
      value={{
        services,
        doctors,
        appointments,
        siteContent,
        supabaseConfig,
        adminUser,
        isAdminLoggedIn: Boolean(adminUser),
        isLoading,
        activeView,
        toast,
        selectedDoctorForBooking,
        selectedServiceForBooking,
        setActiveView,
        setSelectedDoctorForBooking,
        setSelectedServiceForBooking,
        showToast,
        loginAdmin,
        logoutAdmin,
        updateSupabaseConfig,
        testSupabaseConfig,
        addDoctor,
        updateDoctor,
        deleteDoctor,
        addService,
        updateService,
        deleteService,
        bookAppointment,
        updateAppointmentStatus,
        deleteAppointment,
        updateSiteContent
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
