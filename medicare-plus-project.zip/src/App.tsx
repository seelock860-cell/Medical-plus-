/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { WelcomeSection } from './components/WelcomeSection';
import { ServicesSection } from './components/ServicesSection';
import { DoctorsSection } from './components/DoctorsSection';
import { WhyChooseUsSection } from './components/WhyChooseUsSection';
import { AppointmentBookingSection } from './components/AppointmentBookingSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { Doctor, MedicalService } from './types';

function MainAppContent() {
  const {
    activeView,
    toast,
    selectedDoctorForBooking,
    selectedServiceForBooking,
    setSelectedDoctorForBooking,
    setSelectedServiceForBooking
  } = useApp();

  const bookingRef = useRef<HTMLDivElement>(null);

  const scrollToBooking = () => {
    const el = document.getElementById('booking');
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSelectServiceToBook = (service: MedicalService) => {
    setSelectedServiceForBooking(service);
    scrollToBooking();
  };

  const handleSelectDoctorToBook = (doctor: Doctor) => {
    setSelectedDoctorForBooking(doctor);
    scrollToBooking();
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-white text-slate-800 flex flex-col antialiased selection:bg-teal-600 selection:text-white relative">
      
      {/* Toast Notification Container */}
      {toast && (
        <div className="fixed top-5 right-5 z-50 max-w-md w-full animate-in fade-in slide-in-from-top-4 duration-200">
          <div
            className={`p-4 rounded-xl shadow-xl border flex items-start gap-3 ${
              toast.type === 'error'
                ? 'bg-rose-50 border-rose-200 text-rose-900'
                : toast.type === 'info'
                ? 'bg-slate-900 border-slate-800 text-white'
                : 'bg-emerald-50 border-emerald-200 text-emerald-950'
            }`}
          >
            {toast.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            ) : toast.type === 'info' ? (
              <Info className="w-5 h-5 text-teal-400 shrink-0 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            )}
            <div className="text-xs sm:text-sm font-medium leading-relaxed flex-1">
              {toast.message}
            </div>
          </div>
        </div>
      )}

      {/* Switch between Public Website and Admin Dashboard */}
      {activeView === 'admin' ? (
        <AdminDashboard />
      ) : (
        <>
          <Navbar onBookClick={scrollToBooking} />
          
          <main className="flex-1">
            <HeroSection onBookClick={scrollToBooking} />
            <WelcomeSection />
            <ServicesSection onSelectServiceToBook={handleSelectServiceToBook} />
            <DoctorsSection onSelectDoctorToBook={handleSelectDoctorToBook} />
            <WhyChooseUsSection />
            <div ref={bookingRef}>
              <AppointmentBookingSection
                preselectedService={selectedServiceForBooking}
                preselectedDoctor={selectedDoctorForBooking}
                onClearPreselections={() => {
                  setSelectedServiceForBooking(null);
                  setSelectedDoctorForBooking(null);
                }}
              />
            </div>
            <TestimonialsSection />
            <ContactSection />
          </main>

          <Footer />
          <FloatingWhatsApp />
        </>
      )}

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
