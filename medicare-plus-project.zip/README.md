# MEDICARE PLUS - Modern Healthcare & Hospital Platform

A modern, professional, and responsive healthcare platform featuring online appointment booking, doctor profile management, dynamic healthcare services, WhatsApp triage integration, and Supabase cloud database connectivity.

---

## 1. Key Business Information & Credentials

- **Platform Name:** MEDICARE PLUS
- **Platform Type:** Modern Outpatient Healthcare & Hospital System
- **Official WhatsApp Hotline:** `09024971419`
- **Official Telephone:** `09024971419`
- **Location:** Plot 14, Health Park Boulevard, Victoria Island, Lagos, Nigeria
- **Administrator Username:** `morning`
- **Administrator Password:** `morning234` (or Supabase Auth user)

---

## 2. Core Features

1. **Hospital Homepage:**
   - Cinematic hero section with real clinical photography.
   - Value propositions, trust indicators, and fast-track booking.
   - 4-column feature and metric strip (&lt;15 min wait times, 15+ doctors, 25k+ patients).
   - Hospital introduction & 3 clinical care pillars.
   - 7 primary medical departments with interactive details modal.
   - Medical doctors directory with filters, credentials, and consultation booking.
   - Diagnostic laboratory and pathology showcase.
   - Attributable, verified patient outcome testimonials.
   - Contact cards, map coordinates, and emergency notices.

2. **Healthcare Services:**
   - General consultation
   - Dental care
   - Maternity care
   - Paediatrics
   - Laboratory and diagnostics
   - Family healthcare
   - Specialist consultations
   *(Full CRUD management available in the Admin Console)*

3. **Doctor Management:**
   - Add new doctors with photo, qualifications, and specializations.
   - Edit profiles and toggle availability status.
   - Delete doctors.

4. **Appointment Booking Engine:**
   - Full name, verified phone number, email.
   - Department selector & optional doctor preference.
   - Date selector (disallows past dates) and 9 time slot options.
   - Client-side form validation.
   - Instant booking confirmation modal with unique reference code (e.g., `MCP-84920`).
   - 1-click **Confirm via WhatsApp** link sending prefilled booking details to `09024971419`.

5. **WhatsApp Integration:**
   - Floating WhatsApp button with pulsing live badge.
   - Pre-filled enquiry messages directly routing to `09024971419`.
   - Admin "WhatsApp Patient" quick action button in the appointments table.

6. **Administrative Dashboard (Hidden Route):**
   - Access directly via browser address bar at `#/admin`.
   - Hidden from public visitor UI (no buttons or links on the website).
   - Secure login credentials: Username `morning`, Password `morning234` (or Supabase Auth).
   - Overview metrics: Total requests, Pending, Confirmed, Cancelled, Completed.
   - Live appointments filter (search by name, ref code, department, phone).
   - Status actions: Confirm, Reschedule, Complete, Cancel.
   - Full Doctor & Service management.
   - Website content editor (Welcome text, phone, WhatsApp number, emergency notice).
   - In-app Supabase connection tester, credentials config, and SQL script viewer.

---

## 3. Supabase Integration & Setup

The platform is connected to Supabase project `mcnmvvqddhsxmgytcgfk`.

- **Project URL:** `https://mcnmvvqddhsxmgytcgfk.supabase.co`
- **Publishable Key:** `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

### Database Setup:
1. Open your Supabase Dashboard for project `mcnmvvqddhsxmgytcgfk` at [https://supabase.com](https://supabase.com).
2. Click on **SQL Editor** in the left sidebar.
3. Click **New Query**, paste the contents of `supabase/schema.sql` (or copy it directly from Admin Dashboard > Supabase Settings), and click **Run**.
4. All tables (`services`, `doctors`, `appointments`, `site_content`), RLS policies, and seed data will be active immediately.

---

## 4. Deployment Instructions

### A. How to Push All Files to GitHub (Recommended)
To make sure all files including the `src/` folder appear on GitHub:
```bash
# In your terminal inside the project directory:
git init
git add .
git commit -m "Initial Medicare Plus commit"
git branch -M main
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/YOUR_REPOSITORY_NAME.git
git push -u origin main
```

> **Why did Vercel show `Error: Failed to resolve /src/main.tsx`?**
> If you upload files using GitHub's web interface "Upload files" button, browser drag-and-drop can fail to upload directories like `src/`. If the `src/` directory is missing from GitHub, Vercel cannot find `/src/main.tsx` during `npm run build`. Using `git push` or GitHub Desktop ensures every folder and file is uploaded.

### B. Deploy to Vercel
1. Push your repository to GitHub (using the steps above).
2. Sign in to [Vercel](https://vercel.com) and click **Add New Project**.
3. Import your GitHub repository.
4. Framework Preset: **Vite** (auto-detected).
5. Build Command: `npm run build` (auto-detected).
6. Output Directory: `dist` (auto-detected).
7. Under **Environment Variables**, add:
   - `VITE_SUPABASE_URL`: `https://mcnmvvqddhsxmgytcgfk.supabase.co`
   - `VITE_SUPABASE_ANON_KEY`: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jbm12dnFkZGhzeG1neXRjZ2ZrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM1MTM3MzIsImV4cCI6MjEwOTA4OTczMn0.MwhGDpLiZWz5LJryruPYB_wot_dxZF7E7F0uKmuHNQA`
8. Click **Deploy**. Vercel will build successfully!

### B. Local Development & Build
```bash
# Install dependencies
npm install

# Start Vite development server
npm run dev

# Compile TypeScript and build for production
npm run build

# Preview production build
npm run preview
```

---

## 5. Security & Privacy

- **No Secret Key Exposure:** The frontend only utilizes Supabase's public `anon` key. Secret service keys are never included in client bundles.
- **Row Level Security (RLS):** Ensures public users can only insert appointments and view active services/doctors, while modifications require authenticated roles.
- **Emergency Disclaimer:** Clear notice that Medicare Plus provides outpatient and planned healthcare, directing acute emergency cases to national emergency numbers (112).
